/* Theme: light / dark. Loaded in <head> of every page so the right theme is set before first paint.
   Order of precedence: saved choice (localStorage 'tiq-theme') -> system preference (prefers-color-scheme) -> dark. */
(function () {
  var KEY = 'tiq-theme', root = document.documentElement, mq = window.matchMedia ? window.matchMedia('(prefers-color-scheme: light)') : null;
  function saved() { try { var v = localStorage.getItem(KEY); return v === 'light' || v === 'dark' ? v : null; } catch (e) { return null; } }
  function system() { return mq && mq.matches ? 'light' : 'dark'; }
  function apply(t, animate) {
    if (animate) { root.classList.add('theme-anim'); setTimeout(function () { root.classList.remove('theme-anim'); }, 350); }
    root.setAttribute('data-theme', t);
    var m = document.querySelector('meta[name="theme-color"]');
    if (m) m.setAttribute('content', t === 'light' ? '#f3f5fa' : '#0b0f14');
    window.dispatchEvent(new CustomEvent('tiq-theme', { detail: t }));
  }
  var cur = saved() || system();
  root.setAttribute('data-theme', cur);
  window.TIQTheme = {
    get: function () { return root.getAttribute('data-theme'); },
    set: function (t) { try { localStorage.setItem(KEY, t); } catch (e) {} apply(t, true); },
    toggle: function () { this.set(this.get() === 'light' ? 'dark' : 'light'); }
  };
  if (mq && mq.addEventListener) mq.addEventListener('change', function () { if (!saved()) apply(system(), true); });
  window.addEventListener('storage', function (e) { if (e.key === KEY) apply(saved() || system(), true); });
})();
