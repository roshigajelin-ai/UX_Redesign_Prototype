(function () {
  var ic = {
    home: '<path d="M3 11l9-8 9 8v9a1 1 0 0 1-1 1h-5v-6H9v6H4a1 1 0 0 1-1-1z"/>',
    jobs: '<rect x="3" y="7" width="18" height="13" rx="2"/><path d="M9 7V5a2 2 0 0 1 2-2h2a2 2 0 0 1 2 2v2M3 13h18"/>',
    work: '<path d="M9 11l3 3 8-8"/><path d="M20 12v7a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h9"/>',
    learn: '<path d="M2 9l10-5 10 5-10 5z"/><path d="M6 11.5V16c0 1.5 3 3 6 3s6-1.5 6-3v-4.5"/>',
    insights: '<path d="M4 20V10M10 20V4M16 20v-7M22 20H2"/>',
    inbox: '<path d="M18 8a6 6 0 0 0-12 0c0 7-3 8-3 8h18s-3-1-3-8"/><path d="M10 21a2 2 0 0 0 4 0"/>',
    me: '<circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/>',
    sun: '<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/>',
    moon: '<path d="M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8z"/>',
    search: '<circle cx="11" cy="11" r="7"/><path d="M21 21l-4.3-4.3"/>'
  };
  function svg(k) {
    return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + ic[k] + '</svg>';
  }
  function themeBtn() {
    return '<button type="button" class="theme-btn" data-theme-toggle aria-label="Switch colour theme" aria-pressed="false">' +
      svg('moon').replace('<svg', '<svg class="i-moon"') + svg('sun').replace('<svg', '<svg class="i-sun"') + '<span class="tl">Theme</span></button>';
  }
  var page = document.body.getAttribute('data-page') || '';
  var items = [
    ['home', 'index.html', 'Home', 'home'],
    ['jobs', 'jobs.html', 'Jobs', 'jobs'],
    ['work', 'work.html', 'My Work', 'work'],
    ['learn', 'learn.html', 'Learn', 'learn'],
    ['insights', 'insights.html', 'Insights', 'insights'],
    ['inbox', 'inbox.html', 'Inbox', 'inbox']
  ];
  var links = items.map(function (i) {
    var badge = i[0] === 'inbox' ? '<span class="badge">3</span>' : '';
    return '<a href="' + i[1] + '" class="' + (page === i[0] ? 'on' : '') + '"' + (page === i[0] ? ' aria-current="page"' : '') + '>' + svg(i[3]) + i[2] + badge + '</a>';
  }).join('');

  var header = '<header class="topbar"><div class="in">' +
    '<a class="logo" href="index.html"><i></i>TIQ World</a>' +
    '<label class="search">' + svg('search').replace('<svg', '<svg width="16" height="16"') + '<input placeholder="Search jobs, courses, people" aria-label="Search"></label>' +
    '<nav class="nav" aria-label="Main">' + links +
    themeBtn() + '<div class="menu" id="me"><button aria-haspopup="true" aria-expanded="false"><span class="avatar"></span>Me ▾</button>' +
    '<div class="dd"><div class="who"><b>Priya Sample</b><br>NDT Technician · Chennai</div>' +
    '<a href="profile.html">View profile</a><a href="profile.html#skills">Skills &amp; verification</a>' +
    '<a href="certificates.html">Certificates</a><a href="learn.html#investments">Investments &amp; payments</a>' +
    '<hr><div class="who">Design docs</div><a href="compare.html">Comparison</a><a href="ia.html">Navigation map</a><a href="rationale.html">Rationale</a><a href="mobile.html">Mobile view</a><hr><a href="#">Settings</a><a href="#">Sign out</a></div></div>' +
    '</nav>' +
    '<div class="mobile-right">' + themeBtn() + '<a href="inbox.html" aria-label="Notifications" style="position:relative;color:var(--sub)">' + svg('inbox').replace('<svg', '<svg width="22" height="22"') + '<span class="badge" style="right:-6px">3</span></a></div>' +
    '</div></header>';

  var tabbar = '<nav class="tabbar" aria-label="Main">' + [
    ['home', 'index.html', 'Home'], ['jobs', 'jobs.html', 'Jobs'], ['work', 'work.html', 'Work'], ['learn', 'learn.html', 'Learn'], ['insights', 'insights.html', 'Insights'], ['me', 'profile.html', 'Me']
  ].map(function (i) {
    return '<a href="' + i[1] + '" class="' + (page === i[0] ? 'on' : '') + '">' + svg(i[0]) + i[2] + '</a>';
  }).join('') + '</nav>';

  var fab = (page === 'inbox' || page === 'docs') ? '' : '<a class="fab" href="inbox.html#ask"><span>✦</span><span class="t">Ask TIQ</span></a>';
  document.body.insertAdjacentHTML('afterbegin', header);
  document.body.insertAdjacentHTML('beforeend', fab + tabbar);

  function syncTheme() {
    var light = window.TIQTheme && TIQTheme.get() === 'light';
    document.querySelectorAll('[data-theme-toggle]').forEach(function (b) {
      b.setAttribute('aria-pressed', light ? 'true' : 'false');
      b.setAttribute('aria-label', light ? 'Switch to dark mode' : 'Switch to light mode');
      b.title = light ? 'Switch to dark mode' : 'Switch to light mode';
    });
  }
  document.querySelectorAll('[data-theme-toggle]').forEach(function (b) { b.addEventListener('click', function () { TIQTheme.toggle(); }); });
  window.addEventListener('tiq-theme', syncTheme); syncTheme();

  var me = document.getElementById('me');
  me.querySelector('button').addEventListener('click', function (e) {
    e.stopPropagation();
    var o = me.classList.toggle('open');
    this.setAttribute('aria-expanded', o);
  });
  document.addEventListener('click', function () { me.classList.remove('open'); });

  // tabs: <div class="tabs"><button data-t="id">..</button></div> + <section class="panel" id="id">
  document.querySelectorAll('.tabs[data-group]').forEach(function (bar) {
    var btns = bar.querySelectorAll('button');
    function show(id) {
      var found = false;
      btns.forEach(function (b) { if (b.dataset.t === id) found = true; });
      if (!found) id = btns[0].dataset.t;
      btns.forEach(function (b) { b.classList.toggle('on', b.dataset.t === id); });
      document.querySelectorAll('.panel[data-group="' + bar.dataset.group + '"]').forEach(function (p) {
        p.classList.toggle('on', p.id === id);
      });
    }
    btns.forEach(function (b) {
      b.addEventListener('click', function () { show(b.dataset.t); history.replaceState(null, '', '#' + b.dataset.t); });
    });
    window.addEventListener('hashchange', function () { show(location.hash.slice(1)); });
    show(location.hash.slice(1));
    window.scrollTo(0, 0);
    window.addEventListener('hashchange', function () { window.scrollTo(0, 0); });
  });
})();
