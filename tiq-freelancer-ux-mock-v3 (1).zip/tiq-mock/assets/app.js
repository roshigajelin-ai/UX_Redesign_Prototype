/* Shared behaviour for the TIQ World design mock: store, modal, toast, tooltip. All actions are simulated. */
(function () {
  var mem = {};
  var store = {
    get: function (k, d) { try { var v = localStorage.getItem('tiqmock:' + k); return v === null ? (k in mem ? mem[k] : d) : JSON.parse(v); } catch (e) { return k in mem ? mem[k] : d; } },
    set: function (k, v) { mem[k] = v; try { localStorage.setItem('tiqmock:' + k, JSON.stringify(v)); } catch (e) { } }
  };
  function esc(s) { return String(s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }

  // ---------- modal ----------
  var lastFocus = null;
  function closeModal() {
    var m = document.getElementById('tiq-modal'); if (!m) return;
    m.remove(); document.body.style.overflow = '';
    if (lastFocus && lastFocus.focus) lastFocus.focus();
  }
  function modal(opts) {
    closeModal();
    lastFocus = document.activeElement;
    var w = document.createElement('div');
    w.id = 'tiq-modal'; w.className = 'modal-bg';
    w.innerHTML = '<div class="modal" role="dialog" aria-modal="true" aria-labelledby="tiq-modal-t">' +
      '<div class="modal-h"><h2 id="tiq-modal-t">' + esc(opts.title || '') + '</h2><button class="modal-x" aria-label="Close">✕</button></div>' +
      '<div class="modal-b">' + (opts.body || '') + '</div>' +
      '<div class="modal-f">' + (opts.note ? '<span class="note">' + opts.note + '</span>' : '<span></span>') + '<span class="row"></span></div></div>';
    document.body.appendChild(w); document.body.style.overflow = 'hidden';
    var foot = w.querySelector('.modal-f .row');
    (opts.actions || []).forEach(function (a) {
      var b = document.createElement(a.href ? 'a' : 'button');
      b.className = 'btn' + (a.kind ? ' ' + a.kind : ''); b.textContent = a.label;
      if (a.href) b.href = a.href;
      b.addEventListener('click', function (e) { if (a.onClick) a.onClick(e); if (a.close !== false && !a.href) closeModal(); });
      foot.appendChild(b);
    });
    var cl = document.createElement('button'); cl.className = 'btn line'; cl.textContent = 'Close'; cl.addEventListener('click', closeModal); foot.appendChild(cl);
    w.addEventListener('click', function (e) { if (e.target === w) closeModal(); });
    w.querySelector('.modal-x').addEventListener('click', closeModal);
    var first = w.querySelector('.modal-f .btn.primary-focus, .modal-f .btn'); (first || w.querySelector('.modal-x')).focus();
    if (opts.onOpen) opts.onOpen(w);
    return w;
  }
  document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape') closeModal();
    if (e.key === 'Tab') { var m = document.querySelector('#tiq-modal .modal'); if (!m) return; var f = m.querySelectorAll('button,a[href],input,select,textarea'); if (!f.length) return; var a = f[0], z = f[f.length - 1]; if (e.shiftKey && document.activeElement === a) { z.focus(); e.preventDefault(); } else if (!e.shiftKey && document.activeElement === z) { a.focus(); e.preventDefault(); } }
  });

  // ---------- toast ----------
  function toast(msg, sim) {
    var t = document.getElementById('tiq-toast');
    if (!t) { t = document.createElement('div'); t.id = 'tiq-toast'; t.setAttribute('role', 'status'); document.body.appendChild(t); }
    t.innerHTML = esc(msg) + (sim === false ? '' : ' <span class="sample">SIMULATED</span>');
    t.classList.add('on'); clearTimeout(toast._t); toast._t = setTimeout(function () { t.classList.remove('on'); }, 2600);
  }

  // ---------- tooltip ----------
  var tip;
  document.addEventListener('mouseover', function (e) {
    var n = e.target.closest && e.target.closest('[data-tip]'); if (!n) return;
    if (!tip) { tip = document.createElement('div'); tip.id = 'tiq-tip'; document.body.appendChild(tip); }
    tip.textContent = n.getAttribute('data-tip'); tip.style.display = 'block';
  });
  document.addEventListener('mousemove', function (e) { if (tip && tip.style.display === 'block') { tip.style.left = Math.min(e.clientX + 14, innerWidth - 200) + 'px'; tip.style.top = (e.clientY + 14) + 'px'; } });
  document.addEventListener('mouseout', function (e) { if (tip && e.target.closest && e.target.closest('[data-tip]')) tip.style.display = 'none'; });

  // data-modal="id" buttons: open a <template id="id"> as modal
  document.addEventListener('click', function (e) {
    var b = e.target.closest && e.target.closest('[data-open]'); if (!b) return;
    e.preventDefault();
    var t = document.getElementById(b.getAttribute('data-open')); if (!t) return;
    modal({ title: b.getAttribute('data-title') || '', body: t.innerHTML });
  });

  // saved jobs + applications (simulated)
  var jobsApi = {
    saved: function () { return store.get('saved', []); },
    isSaved: function (id) { return jobsApi.saved().indexOf(id) >= 0; },
    toggleSave: function (id) { var s = jobsApi.saved(), i = s.indexOf(id); if (i >= 0) s.splice(i, 1); else s.push(id); store.set('saved', s); return i < 0; },
    applied: function () { return store.get('applied', []); },
    isApplied: function (id) { return jobsApi.applied().indexOf(id) >= 0; },
    apply: function (id) { var a = jobsApi.applied(); if (a.indexOf(id) < 0) a.push(id); store.set('applied', a); },
    get: function (id) { return TIQDATA.jobs.filter(function (j) { return j.id === Number(id); })[0]; }
  };

  window.TIQ = { store: store, esc: esc, modal: modal, closeModal: closeModal, toast: toast, jobs: jobsApi };
})();
