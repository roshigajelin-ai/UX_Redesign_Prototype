/* RESTORED dummy data for the Home, Jobs and Job-detail pages (global TIQDATA).
   The original file was overwritten by mistake and could not be recovered. This version was rebuilt from
   how app.js, jobui.js, index.html, jobs.html and job-detail.html use it. Job titles, counts and scores are
   invented and may differ from the earlier version. All values are dummy data. */
window.TIQDATA = (function () {
  var SKILLS = { UT: 'Ultrasonic Testing', MT: 'Magnetic Particle Testing', PT: 'Liquid Penetrant Testing', RT: 'Radiographic Testing', AE: 'Acoustic Emission (AE)', AI: 'AI in Manufacturing' };
  var rows = [
    // title, company, location, mode, type, skill, industry, cert, exp, openings, match, posted (days ago)
    ['Acoustic Emission Technician', 'Gulf Pipeline Services', 'Mumbai', 'Onsite', 'Contract', 'AE', 'Oil & Gas', 'NDT Level II', 1, 3, 81, 0],
    ['AI Inspection Analyst', 'Fabrik Industrial', 'Bengaluru', 'Remote', 'Contract', 'AI', 'Manufacturing', 'ISO 9712', 1, 2, 87, 1],
    ['MT Inspector (Level II)', 'Northline Aerospace', 'Chennai', 'Hybrid', 'Full Time', 'MT', 'Aerospace', 'NDT Level II', 2, 2, 64, 1],
    ['Ultrasonic Testing Specialist', 'Petrochem Works', 'Hyderabad', 'Onsite', 'Man Month', 'UT', 'Oil & Gas', 'NDT Level II', 2, 4, 52, 2],
    ['Radiographic Interpreter', 'Meridian Power', 'Pune', 'Onsite', 'Full Time', 'RT', 'Power', 'ASNT', 3, 1, 41, 3],
    ['Penetrant Testing Technician', 'Bluewave Marine', 'Chennai', 'Onsite', 'Man Day', 'PT', 'Marine', 'ISO 9712', 1, 5, 47, 3],
    ['AE Monitoring Engineer', 'Ironbridge Labs', 'Pune', 'Hybrid', 'Full Time', 'AE', 'Power', 'ASNT', 2, 2, 78, 4],
    ['Smart Manufacturing Analyst', 'Autocraft Motors', 'Chennai', 'Hybrid', 'Part Time', 'AI', 'Automotive', 'ISO 9712', 0, 3, 83, 5],
    ['UT Level II Inspector', 'Gulf Pipeline Services', 'Mumbai', 'Onsite', 'Contract', 'UT', 'Oil & Gas', 'NDT Level II', 2, 6, 49, 5],
    ['Magnetic Particle Technician', 'Fabrik Industrial', 'Bengaluru', 'Onsite', 'Internship', 'MT', 'Manufacturing', 'None required', 0, 4, 70, 6],
    ['RT Level II Technician', 'Petrochem Works', 'Hyderabad', 'Onsite', 'Man Month', 'RT', 'Oil & Gas', 'ASNT', 2, 2, 38, 7],
    ['PT Level II Inspector', 'Northline Aerospace', 'Chennai', 'Hybrid', 'Full Time', 'PT', 'Aerospace', 'NDT Level II', 2, 1, 44, 8],
    ['Ultrasonic Testing Trainee', 'Meridian Power', 'Pune', 'Onsite', 'Internship', 'UT', 'Power', 'None required', 0, 5, 58, 9],
    ['Remote AI Vision Reviewer', 'Autocraft Motors', 'Bengaluru', 'Remote', 'Part Time', 'AI', 'Automotive', 'None required', 1, 2, 85, 10],
    ['Acoustic Emission Field Engineer', 'Bluewave Marine', 'Mumbai', 'Onsite', 'Man Day', 'AE', 'Marine', 'ISO 9712', 2, 3, 74, 11],
    ['MT Inspector, Pressure Vessels', 'Ironbridge Labs', 'Hyderabad', 'Hybrid', 'Contract', 'MT', 'Manufacturing', 'NDT Level II', 1, 2, 66, 12],
    ['Radiography Safety Officer', 'Gulf Pipeline Services', 'Chennai', 'Onsite', 'Full Time', 'RT', 'Oil & Gas', 'ASNT', 3, 1, 36, 13],
    ['Penetrant Testing Inspector', 'Fabrik Industrial', 'Pune', 'Onsite', 'Contract', 'PT', 'Manufacturing', 'ISO 9712', 1, 3, 50, 14]
  ];
  var jobs = rows.map(function (r, i) {
    return { id: i + 1, title: r[0], company: r[1], location: r[2], mode: r[3], type: r[4], skill: r[5], industry: r[6], cert: r[7], exp: r[8], openings: r[9], match: r[10], posted: r[11] };
  });
  return {
    SKILLS: SKILLS,
    USER_SKILLS: ['AE', 'AI'],
    MODES: ['Onsite', 'Hybrid', 'Remote'],
    TYPES: ['Full Time', 'Contract', 'Man Day', 'Man Month', 'Part Time', 'Internship'],
    LOCS: ['Chennai', 'Mumbai', 'Bengaluru', 'Hyderabad', 'Pune'],
    jobs: jobs,
    profile: { name: 'Priya Sample', initials: 'PS', role: 'NDT Technician', place: 'Chennai, India', strength: 72, nextStep: 'Verify 2 skills to reach 90%' },
    /* dummy workspace data used by Home, My Work, Learn and Certificates (all invented) */
    interviews: [
      { id: 'i1', company: 'Fabrik Industrial', role: 'AI Inspection Analyst', date: '2026-11-14', time: '11:00', mode: 'Video call', initials: 'FI' },
      { id: 'i2', company: 'Northline Aerospace', role: 'MT Inspector (Level II)', date: '2026-11-18', time: '15:00', mode: 'On-site', initials: 'NA' }
    ],
    contracts: [
      { id: 'c1', title: 'Pipeline AE survey', company: 'Gulf Pipeline Services', status: 'Active', progress: 60, reports: [3, 5], deadline: '2026-12-20' },
      { id: 'c2', title: 'AI vision model review', company: 'Autocraft Motors', status: 'Active', progress: 25, reports: [1, 4], deadline: '2027-01-15' }
    ],
    training: [{ id: 't1', title: 'Magnetic Particle Testing', provider: 'TIQ World Training', start: '2026-12-04', hours: 10, done: 0, mode: 'Online' }],
    assessments: [{ id: 'a1', title: 'Magnetic Particle Testing', type: 'Training', status: 'Not started', due: null, passMark: 70 }],
    certificates: [
      { id: 'DUMMY-0001', title: 'AE Basics', issuer: 'TIQ World Training', issued: '2026-06-18', skill: 'AE' },
      { id: 'DUMMY-0002', title: 'NDT Safety Fundamentals', issuer: 'TIQ World Training', issued: '2026-03-09', skill: 'NDT' },
      { id: 'DUMMY-0003', title: 'AI in Manufacturing Foundations', issuer: 'TIQ World Training', issued: '2026-01-22', skill: 'AI' }
    ],
    hours: { labels: ['W1', 'W2', 'W3', 'W4', 'W5', 'W6'], values: [3, 4, 4, 5, 6, 6] },
    readiness: { total: 58, parts: { Skills: 50, Training: 50, Assessments: 40, Certificates: 40, Experience: 50 } },
    notifications: [
      { text: 'Your Magnetic Particle Testing assessment is ready', href: 'learn.html#assessments', when: 'Today', unread: true },
      { text: '3 new jobs match your skills', href: 'jobs.html', when: 'Today', unread: true },
      { text: 'Verify your 2 skills to improve match scores', href: 'profile.html#skills', when: '2 days ago', unread: true },
      { text: 'Magnetic Particle Testing starts on 04 Dec', href: 'learn.html#training', when: '5 days ago', unread: false }
    ]
  };
})();
