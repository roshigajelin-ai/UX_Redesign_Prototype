/* TIQ World insights mock. Vanilla JS + Chart.js. Dummy data only, nothing is sent anywhere. */
(function () {
  'use strict';
  var T = window.INSDATA;
  var $ = function (id) { return document.getElementById(id); };
  /* Theme-aware colours: read from the CSS variables in style.css, re-read when the theme changes. */
  var TEAL, SUB, GRID, SURF, GREEN, AMBER, RED, BLUE, ORANGE, GREY, GREEN2;
  function cssv(n) { return getComputedStyle(document.documentElement).getPropertyValue(n).trim(); }
  function readTheme() {
    TEAL = cssv('--c-teal'); SUB = cssv('--sub'); GRID = cssv('--track'); SURF = cssv('--panel');
    GREEN = cssv('--c-green'); AMBER = cssv('--c-amber'); RED = cssv('--c-red'); BLUE = cssv('--c-blue'); ORANGE = cssv('--c-orange'); GREY = cssv('--c-grey'); GREEN2 = cssv('--c-green2');
    if (window.Chart) {
      Chart.defaults.color = SUB; Chart.defaults.borderColor = GRID;
      var tt = Chart.defaults.plugins.tooltip;
      tt.backgroundColor = cssv('--tip-bg'); tt.borderColor = cssv('--line'); tt.titleColor = cssv('--tip-fg'); tt.bodyColor = cssv('--tip-fg');
    }
  }
  readTheme();

  function esc(s) { return String(s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }
  function rupee(n) { return '₹' + Number(n).toLocaleString('en-IN'); }
  function dim(c) { return c.length === 7 ? c + '4d' : c; }

  // ---------- state ----------
  var DIMS = [
    { k: 'skill', lab: 'Skill', vals: T.SKILLS.map(function (s) { return s.k; }) },
    { k: 'mode', lab: 'Work mode', vals: T.MODES.map(function (s) { return s.k; }) },
    { k: 'type', lab: 'Employment', vals: T.TYPES },
    { k: 'loc', lab: 'Location', vals: T.LOCS },
    { k: 'industry', lab: 'Industry', vals: T.INDUSTRIES.map(function (s) { return s.k; }) }
  ];
  var DV = {}; DIMS.forEach(function (d) { DV[d.k] = d.vals; });
  var state = { sel: { skill: new Set(), mode: new Set(), type: new Set(), loc: new Set(), industry: new Set() }, range: '1Y', data: 'sample' };
  var saved = new Set();
  try { JSON.parse(localStorage.getItem('tiq-mock-saved') || '[]').forEach(function (x) { saved.add(x); }); } catch (e) {}
  function persist() { try { localStorage.setItem('tiq-mock-saved', JSON.stringify(Array.from(saved))); } catch (e) {} }

  var jobById = {}; T.jobs.forEach(function (j) { jobById[j.id] = j; });
  var skillName = {}; T.SKILLS.forEach(function (s) { skillName[s.k] = s.name; });
  function col(d, v) {
    var list = d === 'skill' ? T.SKILLS : d === 'industry' ? T.INDUSTRIES : d === 'mode' ? T.MODES : null;
    if (!list) return TEAL;
    for (var i = 0; i < list.length; i++) if ((list[i].k) === v) return list[i].color;
    return TEAL;
  }

  // ---------- filtering ----------
  function passes(j, skip) {
    for (var i = 0; i < DIMS.length; i++) {
      var d = DIMS[i].k; if (d === skip) continue;
      var s = state.sel[d]; if (s.size && !s.has(j[d])) return false;
    }
    return true;
  }
  function jobsF(skip) { return T.jobs.filter(function (j) { return passes(j, skip); }); }
  var RANGE = { '7D': 7, '30D': 30, '6M': 182, '1Y': 365 };
  function appsF(skip, ignoreRange) {
    if (state.data === 'real') return [];
    return T.apps.filter(function (a) { return (ignoreRange || a.daysAgo < RANGE[state.range]) && passes(jobById[a.job], skip); });
  }
  function count(list, key) { var o = {}; list.forEach(function (x) { o[x[key]] = (o[x[key]] || 0) + 1; }); return o; }
  function anyFilter() { return DIMS.some(function (d) { return state.sel[d.k].size; }); }
  function toggle(d, v) { var s = state.sel[d]; if (s.has(v)) s['delete'](v); else s.add(v); renderAll(); }

  // ---------- per-mode data ----------
  function courses() {
    var list = T.courses[state.data === 'real' ? 'real' : 'sample'];
    return state.sel.skill.size ? list.filter(function (c) { return state.sel.skill.has(c.skill); }) : list;
  }
  var SAMPLE = state_sample();
  function state_sample() {
    return {
      hours: [2, 4, 3.5, 6, 5, 7, 4.5, 8],
      scores: { 'Magnetic Particle Testing': [62, 74, 86], 'Ultrasonic Testing': [55, 68, null] },
      perf: [['Safety procedures', 91], ['Magnetic inspection', 82], ['Defect detection', 74], ['Equipment handling', 63]],
      radar: { labels: ['NDT basics', 'MT testing', 'Defect detection', 'Safety', 'Equipment'], before: [60, 20, 40, 70, 45], after: [88, 92, 82, 90, 70] },
      spend: [['Training', 18000], ['Assessments', 4000], ['Certification', 3000]],
      months: [['May', 3000], ['Jun', 8000], ['Jul', 5000], ['Aug', 0], ['Sep', 6000], ['Oct', 3000]],
      certs: [
        { n: 'Acoustic Emission Basics', d: 'Jun 2026', id: 'DUMMY-0003' },
        { n: 'NDT Safety Fundamentals', d: 'Mar 2026', id: 'DUMMY-0002' },
        { n: 'AI in Manufacturing Foundations', d: 'Jan 2026', id: 'DUMMY-0001' }
      ],
      sched: [['04 Dec 2026', 'Magnetic Particle Testing starts · Online'], ['10 Dec 2026', 'Safety assessment'], ['17 Dec 2026', 'NDT certification exam']],
      assess: 77
    };
  }
  function isReal() { return state.data === 'real'; }

  // ---------- readiness ----------
  var W = [['Skills', 25], ['Training', 20], ['Assessments', 20], ['Certificates', 15], ['Experience', 20]];
  function readiness() {
    var all = T.courses[isReal() ? 'real' : 'sample'];
    var done = 0, tot = 0; all.forEach(function (c) { done += c.done; tot += c.hours; });
    var lv = isReal() ? { AE: 60, AI: 40 } : T.level;
    var declared = Object.keys(lv).filter(function (k) { return lv[k] >= 40; });
    var skills = declared.length ? declared.reduce(function (s, k) { return s + lv[k]; }, 0) / declared.length : 0;
    var comp = [Math.round(skills), tot ? Math.round(done / tot * 100) : 0, isReal() ? 0 : SAMPLE.assess, isReal() ? 0 : Math.round(SAMPLE.certs.length / 5 * 100), 50];
    var score = Math.round(comp.reduce(function (s, v, i) { return s + v * W[i][1] / 100; }, 0));
    return { comp: comp, score: score };
  }

  // ---------- chart setup ----------
  Chart.defaults.font.family = 'Inter,"Segoe UI",system-ui,sans-serif';
  Chart.defaults.font.size = 11;
  Chart.defaults.maintainAspectRatio = false;
  Chart.defaults.animation.duration = 350;
  Chart.defaults.plugins.legend.labels.boxWidth = 10;
  Chart.defaults.plugins.legend.labels.boxHeight = 10;
  Chart.defaults.plugins.tooltip.borderWidth = 1;
  Chart.defaults.plugins.tooltip.padding = 9;
  var CH = {};
  function axes(h) {
    var cat = { grid: { display: false }, border: { display: false }, ticks: { autoSkip: false, maxRotation: 0 } };
    var val = { grid: { color: GRID }, border: { display: false }, beginAtZero: true, ticks: { precision: 0 } };
    return h ? { x: val, y: cat } : { x: cat, y: val };
  }
  function hover(e, els) { if (e.native && e.native.target) e.native.target.style.cursor = els.length ? 'pointer' : 'default'; }
  function mk(id, cfg) { CH[id] = new Chart($(id), cfg); return CH[id]; }
  function empty(id, show, msg) { var e = $('e-' + id); if (e) { e.hidden = !show; if (msg) e.innerHTML = '<div>' + msg + '</div>'; } }
  var EMPTY_APPS = 'No applications yet.<br><a class="teal" href="jobs.html">Browse jobs</a> and apply to see this chart.';

  function dimChart(id, d, kind) {
    var vals = DV[d], bar = kind !== 'donut';
    var cfg = {
      type: bar ? 'bar' : 'doughnut',
      data: { labels: vals, datasets: [{ label: 'Jobs', data: vals.map(function () { return 0; }), backgroundColor: vals.map(function (v) { return col(d, v); }), borderRadius: bar ? 4 : 0, maxBarThickness: 22, borderColor: SURF, borderWidth: bar ? 0 : 2 }] },
      options: {
        onClick: function (e, els) { if (els.length) toggle(d, vals[els[0].index]); },
        onHover: hover,
        plugins: { legend: { display: !bar, position: 'bottom', onClick: function (e, item) { toggle(d, vals[item.index]); } } }
      }
    };
    if (bar) { cfg.options.indexAxis = kind === 'hbar' ? 'y' : 'x'; cfg.options.scales = axes(kind === 'hbar'); }
    else cfg.options.cutout = '60%';
    mk(id, cfg);
  }
  function updDim(id, d) {
    var c = CH[id], cnt = count(jobsF(d), d), s = state.sel[d];
    c.data.datasets[0].data = DV[d].map(function (v) { return cnt[v] || 0; });
    c.data.datasets[0].backgroundColor = DV[d].map(function (v) { var b = col(d, v); return s.size && !s.has(v) ? dim(b) : b; });
    c.update();
  }

  // ---------- modal ----------
  var lastFocus = null;
  function openModal(title, html) {
    lastFocus = document.activeElement;
    $('mt').textContent = title; $('mb').innerHTML = html; $('modal').hidden = false; $('mx').focus();
  }
  function closeModal() { $('modal').hidden = true; if (lastFocus && lastFocus.focus) lastFocus.focus(); }
  function toast(msg) {
    var t = document.createElement('div'); t.className = 'toast'; t.setAttribute('role', 'status'); t.textContent = msg;
    document.body.appendChild(t); setTimeout(function () { t.remove(); }, 2600);
  }

  function jobRows(list, limit) {
    var rows = list.slice(0, limit || list.length).map(function (j) {
      return '<tr class="ins-click" data-job="' + j.id + '"><td><b>' + esc(j.title) + '</b><div class="xs sub">' + esc(j.company) + '</div></td><td>' + esc(j.loc) + '</td><td>' + esc(j.mode) + '</td><td>' + esc(j.type) + '</td><td><span class="pill ' + (j.match >= 75 ? 'g' : j.match >= 55 ? 'y' : '') + '">' + j.match + '%</span></td>' +
        '<td><button class="ins-save" data-save="' + j.id + '" aria-pressed="' + saved.has(j.id) + '">' + (saved.has(j.id) ? 'Saved' : 'Save') + '</button></td></tr>';
    }).join('');
    return '<tr><th>Role</th><th>Location</th><th>Mode</th><th>Type</th><th>Match</th><th></th></tr>' + rows;
  }
  function jobsModal(title, list) {
    openModal(title + ' (' + list.length + ')', list.length ? '<div class="tblwrap"><table id="mtbl">' + jobRows(list, 40) + '</table></div>' + (list.length > 40 ? '<p class="note">Showing the first 40.</p>' : '') : '<p class="sub">Nothing to show for the current filters.</p>');
  }
  function jobModal(id) {
    var j = jobById[id]; if (!j) return;
    openModal(j.title, '<div class="row" style="gap:12px;margin-bottom:10px"><div class="logo-sq">' + j.skill + '</div><div><div class="sub">' + esc(j.company) + ' · ' + esc(j.loc) + '</div><div class="chips" style="margin-top:6px"><span class="pill">' + esc(j.mode) + '</span><span class="pill">' + esc(j.type) + '</span><span class="pill v">' + esc(j.industry) + '</span><span class="pill ' + (j.match >= 75 ? 'g' : 'y') + '">' + j.match + '% match</span></div></div></div>' +
      '<p class="sub sm">Posted ' + (j.daysAgo === 0 ? 'today' : j.daysAgo + ' days ago') + '. Requires ' + esc(skillName[j.skill]) + '. Dummy listing for the design mock.</p>' +
      '<div class="row" style="margin-top:14px"><button class="btn" id="applyBtn" type="button">Apply (simulated)</button><button class="btn line ins-save" data-save="' + j.id + '" aria-pressed="' + saved.has(j.id) + '" type="button">' + (saved.has(j.id) ? 'Saved' : 'Save') + '</button><a class="btn ghost" href="job-detail.html">Open full job page</a></div>');
    $('applyBtn').onclick = function () { toast('Simulated. Nothing was submitted to a backend.'); };
  }
  function appsModal(title, list) {
    openModal(title + ' (' + list.length + ')', list.length ? '<div class="tblwrap"><table>' + appRows(list) + '</table></div>' : '<p class="sub">No applications here.</p>');
  }
  var STAGES = ['Applied', 'Under review', 'Shortlisted', 'Interview', 'Selected'];
  function statusOf(a) { return a.reached === 4 ? 'Selected' : a.rejected ? 'Rejected' : a.reached >= 2 ? 'In progress' : 'Under review'; }
  function appRows(list) {
    return '<tr><th>Role</th><th>Stage reached</th><th>Status</th><th>Applied</th></tr>' + list.slice().sort(function (a, b) { return a.daysAgo - b.daysAgo; }).map(function (a) {
      var j = jobById[a.job], st = statusOf(a);
      return '<tr class="ins-click" data-job="' + j.id + '"><td><b>' + esc(j.title) + '</b><div class="xs sub">' + esc(j.company) + '</div></td><td>' + STAGES[a.reached] + '</td><td><span class="pill ' + ({ Selected: 'g', Rejected: 'r', 'In progress': 't', 'Under review': 'y' }[st]) + '">' + st + '</span></td><td>' + (a.daysAgo === 0 ? 'today' : a.daysAgo + ' d ago') + '</td></tr>';
    }).join('');
  }
  function tableModal(id) {
    var c = CH[id]; if (!c) return;
    var head = '<tr><th></th>' + c.data.datasets.map(function (d) { return '<th>' + esc(d.label || 'Value') + '</th>'; }).join('') + '</tr>';
    var rows = c.data.labels.map(function (l, i) { return '<tr><td>' + esc(l) + '</td>' + c.data.datasets.map(function (d) { var v = d.data[i]; return '<td>' + (v === null || v === undefined ? '—' : (typeof v === 'number' ? Math.round(v * 10) / 10 : esc(v))) + '</td>'; }).join('') + '</tr>'; }).join('');
    var title = c.canvas.getAttribute('aria-label') || 'Chart data';
    openModal(title + ' · table view', '<div class="tblwrap"><table>' + head + rows + '</table></div>');
  }

  // ---------- slicers ----------
  function renderSlicers() {
    var html = DIMS.map(function (d) {
      var cnt = count(jobsF(d.k), d.k);
      return '<div class="srow"><span class="lab">' + d.lab + '</span>' + d.vals.map(function (v) {
        return '<button type="button" class="chip" data-d="' + d.k + '" data-v="' + esc(v) + '" aria-pressed="' + state.sel[d.k].has(v) + '">' + esc(v) + ' <span class="xs">' + (cnt[v] || 0) + '</span></button>';
      }).join('') + '</div>';
    }).join('');
    $('slicerBody').innerHTML = html;
    var n = DIMS.reduce(function (s, d) { return s + state.sel[d.k].size; }, 0);
    $('fcount').hidden = !n; $('fcount').textContent = n; $('clear').hidden = !n;
  }

  // ---------- KPIs ----------
  function spark(arr) {
    var max = Math.max.apply(null, arr), min = Math.min.apply(null, arr);
    var flat = arr.length < 2 || max === min && max === 0;
    var pts = arr.map(function (v, i) { var x = arr.length > 1 ? i / (arr.length - 1) * 100 : 0, y = flat ? 26 : 26 - (v - min) / ((max - min) || 1) * 24; return x.toFixed(1) + ',' + y.toFixed(1); }).join(' ');
    return '<svg viewBox="0 0 100 28" preserveAspectRatio="none" aria-hidden="true"><polyline points="' + pts + '" fill="none" stroke="' + (flat ? GREY : TEAL) + '" stroke-width="2" vector-effect="non-scaling-stroke" stroke-linejoin="round"/></svg>';
  }
  function weekly(list, fn) { var a = []; for (var w = 11; w >= 0; w--) { var sub = list.filter(function (j) { return Math.floor(j.daysAgo / 7) === w; }); a.push(sub.length ? fn(sub) : 0); } return a; }
  function renderKPIs() {
    var jobs = jobsF(), apps = appsF(), all = appsF(null, true);
    var avg = jobs.length ? Math.round(jobs.reduce(function (s, j) { return s + j.match; }, 0) / jobs.length) : null;
    var newW = jobs.filter(function (j) { return j.daysAgo < 7; }).length;
    var sel = all.filter(function (a) { return a.reached === 4; }).length;
    var cs = courses(), done = 0, tot = 0; cs.forEach(function (c) { done += c.done; tot += c.hours; });
    var rd = readiness();
    var items = [
      { k: 'jobs', l: 'Open jobs', v: jobs.length, d: newW + ' new this week', s: weekly(jobs, function (x) { return x.length; }) },
      { k: 'match', l: 'Average match', v: avg === null ? '—' : avg + '%', d: jobs.length ? 'Best: ' + Math.max.apply(null, jobs.map(function (j) { return j.match; })) + '%' : 'No jobs match', s: weekly(jobs, function (x) { return x.reduce(function (s, j) { return s + j.match; }, 0) / x.length; }) },
      { k: 'apps', l: 'Applications', v: apps.length, d: isReal() ? 'None yet' : 'in selected range', s: trendCounts(all, '1Y') },
      { k: 'rate', l: 'Success rate', v: all.length ? Math.round(sel / all.length * 100) + '%' : '—', d: all.length ? sel + ' of ' + all.length + ' selected' : 'No applications', s: [] },
      { k: 'learn', l: 'Learning progress', v: tot ? Math.round(done / tot * 100) + '%' : '—', d: cs.length + ' course' + (cs.length === 1 ? '' : 's'), s: isReal() ? [] : SAMPLE.hours },
      { k: 'ready', l: 'Career readiness', v: rd.score + '%', d: 'weighted score', s: isReal() ? [] : [30, 36, 41, 47, 52, rd.score] }
    ];
    $('kpis').innerHTML = items.map(function (i) {
      return '<button type="button" class="kpi2" data-kpi="' + i.k + '"><div class="l">' + i.l + '</div><div class="v">' + i.v + '</div><div class="d">' + i.d + '</div>' + spark(i.s) + '</button>';
    }).join('');
  }

  // ---------- trend ----------
  var TREND = { '7D': { n: 7, size: 1 }, '30D': { n: 6, size: 5 }, '6M': { n: 6, size: 30 }, '1Y': { n: 12, size: 30 } };
  var MON = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'], DAY = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
  var TODAY = new Date(2026, 9, 12);
  function trendCounts(list, range) {
    var c = TREND[range], out = []; for (var i = c.n - 1; i >= 0; i--) out.push(list.filter(function (a) { return Math.floor(a.daysAgo / c.size) === i; }).length); return out;
  }
  function trendLabels(range) {
    var c = TREND[range], out = [];
    for (var i = c.n - 1; i >= 0; i--) { var d = new Date(TODAY.getTime() - i * c.size * 86400000); out.push(range === '7D' ? DAY[d.getDay()] + ' ' + d.getDate() : range === '30D' ? d.getDate() + ' ' + MON[d.getMonth()] : MON[d.getMonth()]); }
    return out;
  }
  function renderTrend() {
    var apps = appsF(), c = CH['c-trend'];
    c.data.labels = trendLabels(state.range);
    c.data.datasets[0].data = trendCounts(apps, state.range);
    c.update();
    empty('c-trend', !apps.length, isReal() ? EMPTY_APPS : 'No applications match these filters in this range.<br><button class="btn ghost sm" type="button" id="clr2" style="margin-top:8px">Clear filters</button>');
    var b = $('clr2'); if (b) b.onclick = clearAll;
  }

  // ---------- funnel + status ----------
  function renderFunnel() {
    var apps = appsF(), box = $('fun');
    $('e-fun').hidden = apps.length > 0; box.hidden = apps.length === 0;
    $('e-fun').innerHTML = '<div>' + (isReal() ? EMPTY_APPS : 'No applications match these filters.') + '</div>';
    if (!apps.length) { box.innerHTML = ''; return; }
    var counts = STAGES.map(function (s, i) { return apps.filter(function (a) { return a.reached >= i; }).length; });
    box.innerHTML = STAGES.map(function (s, i) {
      var w = Math.max(8, counts[i] / counts[0] * 100), cv = i ? Math.round(counts[i] / (counts[i - 1] || 1) * 100) + '% of prev.' : '';
      return '<button type="button" data-stage="' + i + '" aria-label="' + s + ': ' + counts[i] + '"><span class="nm">' + s + '</span><span class="bar" style="width:' + w * 0.62 + '%;opacity:' + (1 - i * 0.13) + '">' + counts[i] + '</span><span class="cv">' + cv + '</span></button>';
    }).join('');
    var rate = counts[0] ? Math.round(counts[4] / counts[0] * 1000) / 10 : 0;
    box.insertAdjacentHTML('beforeend', '<div class="note">Success rate: ' + counts[4] + ' selected / ' + counts[0] + ' applications = ' + rate + '%</div>');
  }
  function statusCounts(apps) {
    var o = { 'Selected': [], 'In progress': [], 'Under review': [], 'Rejected': [] };
    apps.forEach(function (a) { o[statusOf(a)].push(a); }); return o;
  }
  var STATUS_ORDER = ['Selected', 'In progress', 'Under review', 'Rejected'];

  // ---------- readiness / gap / NBA ----------
  function renderReadiness() {
    var r = readiness(); $('gscore').textContent = r.score;
    var g = CH['c-gauge']; g.data.datasets[0].data = [r.score, 100 - r.score]; g.update();
    $('rbars').innerHTML = W.map(function (w, i) {
      return '<div class="hbar"><div class="t"><span>' + w[0] + ' <span class="faint">(' + w[1] + '%)</span></span><b>' + r.comp[i] + '%</b></div><div class="meter"><i style="width:' + r.comp[i] + '%"></i></div></div>';
    }).join('');
    $('rformula').textContent = 'Score = 25% skills + 20% training + 20% assessments + 15% certificates + 20% experience. Weights are a proposal for review.';
  }
  function renderGap() {
    var cnt = count(jobsF('skill'), 'skill'), max = Math.max.apply(null, T.SKILLS.map(function (s) { return cnt[s.k] || 0; })) || 1;
    var lv = isReal() ? { AE: 60, AI: 40 } : T.level, c = CH['c-gap'];
    c.data.datasets[0].data = T.SKILLS.map(function (s) { return Math.round((cnt[s.k] || 0) / max * 100); });
    c.data.datasets[1].data = T.SKILLS.map(function (s) { return lv[s.k] || 0; });
    c.update();
  }
  function renderNBA() {
    var all = T.jobs, N = all.length, byS = count(all, 'skill'), lv = isReal() ? { AE: 60, AI: 40 } : T.level;
    var enr = T.courses[isReal() ? 'real' : 'sample'].filter(function (c) { return c.done < c.hours; })[0];
    var gapSkill = T.SKILLS.slice().sort(function (a, b) { return (byS[b.k] - (lv[b.k] || 0) * byS[b.k] / 100) - (byS[a.k] - (lv[a.k] || 0) * byS[a.k] / 100); })[0];
    var html = '<div class="head"><h2>Next best actions</h2><span class="xs sub">computed from this dataset</span></div><div class="g2">';
    if (enr) html += '<div class="callout"><b>Finish ' + esc(enr.name) + '</b><div class="sm sub" style="margin:4px 0 8px">' + esc(enr.skill) + ' appears in ' + byS[enr.skill] + ' of ' + N + ' jobs (' + Math.round(byS[enr.skill] / N * 100) + '%). ' + (enr.done ? Math.round(enr.done / enr.hours * 100) + '% complete.' : 'Not started yet.') + '</div><a class="btn sm" href="learn.html#training">Open course</a> <button class="btn line sm" type="button" data-nba-skill="' + enr.skill + '">Show ' + enr.skill + ' jobs</button></div>';
    html += '<div class="callout"><b>Close the biggest gap: ' + esc(gapSkill.name) + '</b><div class="sm sub" style="margin:4px 0 8px">Appears in ' + byS[gapSkill.k] + ' of ' + N + ' jobs. Your self-declared level is ' + (lv[gapSkill.k] || 0) + '/100.</div><a class="btn sm" href="learn.html#catalog">Browse courses</a> <button class="btn line sm" type="button" data-nba-skill="' + gapSkill.k + '">Show ' + gapSkill.k + ' jobs</button></div></div>';
    $('nba').innerHTML = html;
  }

  // ---------- tables ----------
  function renderJobTable() {
    var list = jobsF().slice().sort(function (a, b) { return b.match - a.match; });
    $('jobtbl').innerHTML = list.length ? jobRows(list, 8) : '<tr><td class="sub">No jobs match these filters. <button class="btn ghost sm" type="button" id="clr3">Clear filters</button></td></tr>';
    var b = $('clr3'); if (b) b.onclick = clearAll;
  }
  function renderAppTable() {
    var apps = appsF();
    $('apptbl').innerHTML = apps.length ? appRows(apps) : '<tr><td class="sub">' + (isReal() ? 'No applications yet. <a class="teal" href="jobs.html">Browse jobs</a>' : 'No applications match these filters.') + '</td></tr>';
  }

  // ---------- applications tab ----------
  function renderAppCharts() {
    var apps = appsF(), st = statusCounts(apps), c = CH['c-status'];
    c.data.datasets[0].data = STATUS_ORDER.map(function (k) { return st[k].length; }); c.update();
    empty('c-status', !apps.length, isReal() ? EMPTY_APPS : 'No applications match these filters.');
    var ap = CH['c-appskill'], sk = appsF('skill'), cnt = {}; sk.forEach(function (a) { var s = jobById[a.job].skill; cnt[s] = (cnt[s] || 0) + 1; });
    var s = state.sel.skill;
    ap.data.datasets[0].data = DV.skill.map(function (v) { return cnt[v] || 0; });
    ap.data.datasets[0].backgroundColor = DV.skill.map(function (v) { var b = col('skill', v); return s.size && !s.has(v) ? dim(b) : b; });
    ap.update(); empty('c-appskill', !sk.length, isReal() ? EMPTY_APPS : 'No applications match these filters.');
    var counts = STAGES.map(function (x, i) { return apps.filter(function (a) { return a.reached >= i; }).length; });
    $('conv').innerHTML = apps.length ? STAGES.slice(1).map(function (x, i) {
      var p = counts[i] ? Math.round(counts[i + 1] / counts[i] * 100) : 0;
      return '<div class="hbar"><div class="t"><span>' + STAGES[i] + ' → ' + x + '</span><b>' + p + '%</b></div><div class="meter"><i style="width:' + p + '%"></i></div><div class="xs faint">' + counts[i + 1] + ' of ' + counts[i] + '</div></div>';
    }).join('') : '<div class="sub sm">No data yet.</div>';
  }

  // ---------- learning tab ----------
  function renderLearning() {
    var cs = courses();
    $('courses').innerHTML = cs.length ? cs.map(function (c) {
      var p = Math.round(c.done / c.hours * 100), st = p >= 100 ? ['Completed', 'g'] : p > 0 ? ['In progress', 't'] : ['Not started', ''];
      return '<a class="hbar" style="display:block" href="learn.html#training"><div class="t"><span><b>' + esc(c.name) + '</b> <span class="faint">' + c.skill + '</span></span><span class="pill ' + st[1] + '">' + st[0] + '</span></div><div class="meter"><i style="width:' + p + '%"></i></div><div class="xs faint">' + c.done + ' / ' + c.hours + ' h (' + p + '%)</div></a>';
    }).join('') : '<div class="sub sm">No course for the selected skill. Clear the skill filter or browse the catalog.</div>';
    var n = { Completed: 0, 'In progress': 0, 'Not started': 0 };
    cs.forEach(function (c) { n[c.done >= c.hours ? 'Completed' : c.done > 0 ? 'In progress' : 'Not started']++; });
    var l = CH['c-lstatus']; l.data.datasets[0].data = [n.Completed, n['In progress'], n['Not started']]; l.update();
    var h = CH['c-hours']; h.data.datasets[0].data = isReal() ? [] : SAMPLE.hours; h.data.labels = isReal() ? [] : SAMPLE.hours.map(function (x, i) { return 'W' + (i + 1); }); h.update();
    empty('c-hours', isReal(), 'No study hours logged yet.<br>Start a course to see your weekly hours.');
    var rd = CH['c-radar']; rd.data.datasets[0].data = SAMPLE.radar.before; rd.data.datasets[1].data = SAMPLE.radar.after; rd.update();
    empty('c-radar', isReal(), 'Finish a course to compare your skills before and after training.');
    var cells = '';
    for (var d = 0; d < 7; d++) for (var w = 0; w < 12; w++) { var lv = isReal() ? 0 : T.heat[w * 7 + d]; cells += '<i data-l="' + lv + '" title="Week ' + (w + 1) + ', ' + DAY[(d + 1) % 7] + ': ' + ['no study', 'light', 'moderate', 'busy', 'very busy'][lv] + '"></i>'; }
    $('heat').innerHTML = cells;
    var sch = isReal() ? [['04 Dec 2026', 'Magnetic Particle Testing starts · Online'], ['17 Aug 2026', 'Assessment window open']] : SAMPLE.sched;
    $('sched').innerHTML = sch.map(function (x) { return '<div><b class="sm">' + x[0] + '</b><div class="sm sub">' + x[1] + '</div></div>'; }).join('');
  }

  // ---------- credentials tab ----------
  function renderCred() {
    var real = isReal(), certs = real ? [] : SAMPLE.certs, tot = real ? 0 : SAMPLE.spend.reduce(function (s, x) { return s + x[1]; }, 0);
    var k = [['Total invested', rupee(tot), real ? 'No payments yet' : 'training, tests, certificates'], ['Certificates earned', certs.length, real ? 'Pass an assessment to earn one' : 'verified on your profile'], ['Average score', real ? '—' : SAMPLE.assess + '%', real ? 'No attempts yet' : 'pass mark 70%'], ['Cost per certificate', certs.length ? rupee(Math.round(tot / certs.length)) : '—', certs.length ? 'total ÷ certificates' : 'Not available yet']];
    $('spendkpi').innerHTML = k.map(function (x) { return '<div class="kpi2" style="cursor:default"><div class="l">' + x[0] + '</div><div class="v">' + x[1] + '</div><div class="d">' + x[2] + '</div></div>'; }).join('');
    var sc = CH['c-score'], names = Object.keys(SAMPLE.scores);
    sc.data.labels = ['Attempt 1', 'Attempt 2', 'Attempt 3'];
    names.forEach(function (n, i) { sc.data.datasets[i].data = real ? [] : SAMPLE.scores[n]; });
    sc.data.datasets[2].data = real ? [] : [70, 70, 70]; sc.update();
    empty('c-score', real, 'No assessment attempts yet.<br><a class="teal" href="learn.html#assessments">Take your first assessment</a>');
    var p = CH['c-perf']; p.data.labels = real ? [] : SAMPLE.perf.map(function (x) { return x[0]; });
    p.data.datasets[0].data = real ? [] : SAMPLE.perf.map(function (x) { return x[1]; });
    p.data.datasets[0].backgroundColor = real ? [] : SAMPLE.perf.map(function (x) { return x[1] < 70 ? AMBER : TEAL; });
    p.update(); empty('c-perf', real, 'Skill scores appear after your first assessment.');
    var sp = CH['c-spend']; sp.data.labels = real ? [] : SAMPLE.spend.map(function (x) { return x[0]; }); sp.data.datasets[0].data = real ? [] : SAMPLE.spend.map(function (x) { return x[1]; }); sp.update();
    empty('c-spend', real, 'No payments yet.');
    var mo = CH['c-month']; mo.data.labels = real ? [] : SAMPLE.months.map(function (x) { return x[0]; }); mo.data.datasets[0].data = real ? [] : SAMPLE.months.map(function (x) { return x[1]; }); mo.update();
    empty('c-month', real, 'No payments yet.');
    $('certs').innerHTML = certs.length ? certs.map(function (c, i) { return '<button type="button" class="ins-cert" data-cert="' + i + '"><div class="pill g" style="margin-bottom:6px">Verified</div><div><b>' + esc(c.n) + '</b></div><div class="xs sub">Issued ' + c.d + '</div></button>'; }).join('') :
      '<div class="callout" style="grid-column:1/-1">No certificates yet. Pass the Magnetic Particle Testing assessment to earn your first. <a class="teal" href="learn.html#assessments">Go to assessment</a></div>';
  }

  // ---------- master render ----------
  function renderAll() {
    renderSlicers(); renderKPIs();
    updDim('c-skill', 'skill'); updDim('c-industry', 'industry'); updDim('c-mode', 'mode'); updDim('c-type', 'type'); updDim('c-loc', 'loc');
    var jobs = jobsF(), bins = [0, 0, 0, 0];
    jobs.forEach(function (j) { bins[j.match < 40 ? 0 : j.match < 60 ? 1 : j.match < 80 ? 2 : 3]++; });
    CH['c-match'].data.datasets[0].data = bins; CH['c-match'].update();
    var wk = [], wl = []; for (var w = 11; w >= 0; w--) { wk.push(jobs.filter(function (j) { return Math.floor(j.daysAgo / 7) === w; }).length); var d = new Date(TODAY.getTime() - w * 7 * 86400000); wl.push(d.getDate() + ' ' + MON[d.getMonth()]); }
    CH['c-posted'].data.labels = wl; CH['c-posted'].data.datasets[0].data = wk; CH['c-posted'].update();
    renderTrend(); renderFunnel(); renderReadiness(); renderGap(); renderNBA(); renderJobTable(); renderAppTable(); renderAppCharts(); renderLearning(); renderCred();
  }
  function clearAll() { DIMS.forEach(function (d) { state.sel[d.k].clear(); }); renderAll(); }

  // ---------- build charts ----------
  function build() {
    dimChart('c-skill', 'skill', 'hbar'); dimChart('c-industry', 'industry', 'donut'); dimChart('c-mode', 'mode', 'donut'); dimChart('c-type', 'type', 'hbar'); dimChart('c-loc', 'loc', 'hbar');
    mk('c-match', { type: 'bar', data: { labels: ['Under 40%', '40–59%', '60–79%', '80%+'], datasets: [{ label: 'Jobs', data: [0, 0, 0, 0], backgroundColor: TEAL, borderRadius: 4, maxBarThickness: 36 }] }, options: { scales: axes(false), plugins: { legend: { display: false } } } });
    mk('c-posted', { type: 'line', data: { labels: [], datasets: [{ label: 'New jobs', data: [], borderColor: TEAL, backgroundColor: (TEAL + '26'), fill: true, tension: .3, borderWidth: 2, pointRadius: 3, pointBackgroundColor: TEAL, pointBorderColor: SURF, pointBorderWidth: 2 }] }, options: { scales: axes(false), plugins: { legend: { display: false } } } });
    mk('c-trend', { type: 'line', data: { labels: [], datasets: [{ label: 'Applications', data: [], borderColor: TEAL, backgroundColor: (TEAL + '26'), fill: true, tension: .3, borderWidth: 2, pointRadius: 4, pointHoverRadius: 6, pointBackgroundColor: TEAL, pointBorderColor: SURF, pointBorderWidth: 2 }] }, options: { interaction: { mode: 'index', intersect: false }, scales: axes(false), plugins: { legend: { display: false } }, onClick: function (e, els) { if (els.length) { var i = els[0].index, c = TREND[state.range]; var b = c.n - 1 - i; appsModal('Applications in ' + CH['c-trend'].data.labels[i], appsF().filter(function (a) { return Math.floor(a.daysAgo / c.size) === b; })); } }, onHover: hover } });
    mk('c-gauge', { type: 'doughnut', data: { labels: ['Score', 'Remaining'], datasets: [{ data: [0, 100], backgroundColor: [TEAL, GRID], borderWidth: 0 }] }, options: { rotation: -90, circumference: 180, cutout: '78%', plugins: { legend: { display: false }, tooltip: { enabled: false } } } });
    mk('c-gap', { type: 'bar', data: { labels: T.SKILLS.map(function (s) { return s.k; }), datasets: [{ label: 'Market demand index', data: [], backgroundColor: BLUE, borderRadius: 4, maxBarThickness: 12 }, { label: 'Your proficiency', data: [], backgroundColor: ORANGE, borderRadius: 4, maxBarThickness: 12 }] }, options: { indexAxis: 'y', scales: { x: { max: 100, grid: { color: GRID }, border: { display: false }, beginAtZero: true }, y: { grid: { display: false }, border: { display: false } } }, plugins: { legend: { position: 'bottom' } }, onClick: function (e, els) { if (els.length) toggle('skill', T.SKILLS[els[0].index].k); }, onHover: hover } });
    mk('c-status', { type: 'doughnut', data: { labels: STATUS_ORDER, datasets: [{ label: 'Applications', data: [], backgroundColor: [GREEN, BLUE, AMBER, RED], borderColor: SURF, borderWidth: 2 }] }, options: { cutout: '60%', plugins: { legend: { position: 'bottom' } }, onHover: hover, onClick: function (e, els) { if (els.length) { var k = STATUS_ORDER[els[0].index]; appsModal(k, statusCounts(appsF())[k]); } } } });
    mk('c-appskill', { type: 'bar', data: { labels: DV.skill, datasets: [{ label: 'Applications', data: [], backgroundColor: DV.skill.map(function (v) { return col('skill', v); }), borderRadius: 4, maxBarThickness: 22 }] }, options: { indexAxis: 'y', scales: axes(true), plugins: { legend: { display: false } }, onHover: hover, onClick: function (e, els) { if (els.length) toggle('skill', DV.skill[els[0].index]); } } });
    mk('c-lstatus', { type: 'doughnut', data: { labels: ['Completed', 'In progress', 'Not started'], datasets: [{ label: 'Courses', data: [], backgroundColor: [GREEN, BLUE, GREY], borderColor: SURF, borderWidth: 2 }] }, options: { cutout: '60%', plugins: { legend: { position: 'bottom' } } } });
    mk('c-hours', { type: 'bar', data: { labels: [], datasets: [{ label: 'Hours', data: [], backgroundColor: TEAL, borderRadius: 4, maxBarThickness: 22 }] }, options: { scales: axes(false), plugins: { legend: { display: false } } } });
    mk('c-radar', { type: 'radar', data: { labels: SAMPLE.radar.labels, datasets: [{ label: 'Before training', data: [], borderColor: BLUE, backgroundColor: (BLUE + '2e'), borderWidth: 2, pointRadius: 3 }, { label: 'After training', data: [], borderColor: ORANGE, backgroundColor: 'rgba(217,89,38,.18)', borderWidth: 2, pointRadius: 3 }] }, options: { scales: { r: { min: 0, max: 100, grid: { color: GRID }, angleLines: { color: GRID }, ticks: { display: false }, pointLabels: { color: SUB, font: { size: 11 } } } }, plugins: { legend: { position: 'bottom' } } } });
    mk('c-score', { type: 'line', data: { labels: [], datasets: [
      { label: 'Magnetic Particle Testing', data: [], borderColor: BLUE, backgroundColor: BLUE, borderWidth: 2, pointRadius: 4, tension: .25 },
      { label: 'Ultrasonic Testing', data: [], borderColor: ORANGE, backgroundColor: ORANGE, borderWidth: 2, pointRadius: 4, tension: .25 },
      { label: 'Pass mark', data: [], borderColor: SUB, borderDash: [5, 4], borderWidth: 1.5, pointRadius: 0 }] }, options: { scales: { x: { grid: { display: false }, border: { display: false } }, y: { min: 0, max: 100, grid: { color: GRID }, border: { display: false } } }, plugins: { legend: { position: 'bottom' } } } });
    mk('c-perf', { type: 'bar', data: { labels: [], datasets: [{ label: 'Score %', data: [], backgroundColor: [], borderRadius: 4, maxBarThickness: 22 }] }, options: { indexAxis: 'y', scales: { x: { min: 0, max: 100, grid: { color: GRID }, border: { display: false } }, y: { grid: { display: false }, border: { display: false } } }, plugins: { legend: { display: false }, tooltip: { callbacks: { afterLabel: function (c) { return c.parsed.x < 70 ? 'Below the 70% pass mark' : ''; } } } } } });
    mk('c-spend', { type: 'doughnut', data: { labels: [], datasets: [{ label: '₹', data: [], backgroundColor: [BLUE, ORANGE, GREEN2], borderColor: SURF, borderWidth: 2 }] }, options: { cutout: '60%', plugins: { legend: { position: 'bottom' }, tooltip: { callbacks: { label: function (c) { return ' ' + c.label + ': ' + rupee(c.parsed); } } } } } });
    mk('c-month', { type: 'bar', data: { labels: [], datasets: [{ label: 'Spend (₹)', data: [], backgroundColor: TEAL, borderRadius: 4, maxBarThickness: 28 }] }, options: { scales: axes(false), plugins: { legend: { display: false }, tooltip: { callbacks: { label: function (c) { return ' ' + rupee(c.parsed.y); } } } } } });
  }

  // ---------- events ----------
  function bind() {
    document.addEventListener('click', function (e) {
      var t = e.target;
      var chip = t.closest('.chip[data-d]'); if (chip) { toggle(chip.dataset.d, chip.dataset.v); return; }
      var sv = t.closest('[data-save]');
      if (sv) { e.stopPropagation(); var id = +sv.dataset.save; if (saved.has(id)) saved['delete'](id); else saved.add(id); persist(); toast(saved.has(id) ? 'Saved on this device (simulated)' : 'Removed from saved'); document.querySelectorAll('[data-save="' + id + '"]').forEach(function (b) { b.setAttribute('aria-pressed', saved.has(id)); b.textContent = saved.has(id) ? 'Saved' : 'Save'; }); return; }
      var row = t.closest('[data-job]'); if (row) { jobModal(+row.dataset.job); return; }
      var tb = t.closest('.tblbtn'); if (tb) { tableModal(tb.dataset.chart); return; }
      var st = t.closest('[data-stage]'); if (st) { var i = +st.dataset.stage; appsModal(STAGES[i] + ' stage and beyond', appsF().filter(function (a) { return a.reached >= i; })); return; }
      var kp = t.closest('[data-kpi]');
      if (kp) { var k = kp.dataset.kpi;
        if (k === 'jobs') jobsModal('Open jobs', jobsF());
        else if (k === 'match') jobsModal('Jobs by match', jobsF().slice().sort(function (a, b) { return b.match - a.match; }));
        else if (k === 'apps') appsModal('Applications', appsF());
        else if (k === 'rate') appsModal('Selected applications', appsF(null, true).filter(function (a) { return a.reached === 4; }));
        else if (k === 'learn') location.hash = '#learning';
        else { var r = readiness(); openModal('Career readiness: ' + r.score + '%', '<div class="tblwrap"><table><tr><th>Component</th><th>Weight</th><th>Value</th></tr>' + W.map(function (w, i) { return '<tr><td>' + w[0] + '</td><td>' + w[1] + '%</td><td>' + r.comp[i] + '%</td></tr>'; }).join('') + '</table></div><p class="note">Proposed formula for review. Not yet backed by real APIs.</p>'); }
        return; }
      var nb = t.closest('[data-nba-skill]'); if (nb) { state.sel.skill.clear(); state.sel.skill.add(nb.dataset.nbaSkill); renderAll(); location.hash = '#jobs'; return; }
      var ct = t.closest('[data-cert]'); if (ct) { var c = SAMPLE.certs[+ct.dataset.cert]; openModal('Credential preview', '<div class="certview"><div class="xs teal" style="letter-spacing:2px">TIQ WORLD · CERTIFICATE OF COMPLETION</div><h1 style="margin:14px 0 4px">' + esc(c.n) + '</h1><div class="sub">Awarded to <b style="color:#fff">Priya Sample</b></div><div class="sub sm" style="margin-top:10px">Issued ' + c.d + ' · ID ' + c.id + '</div></div><p class="note">Illustrative design with dummy data. Not a real credential.</p>'); return; }
      if (t.closest('#mx') || t === $('modal')) closeModal();
    });
    document.addEventListener('keydown', function (e) { if (e.key === 'Escape' && !$('modal').hidden) closeModal(); });
    $('clear').onclick = function (e) { e.preventDefault(); clearAll(); };
    $('rangeSeg').addEventListener('click', function (e) { var b = e.target.closest('button'); if (!b) return; state.range = b.dataset.r; $('rangeSeg').querySelectorAll('button').forEach(function (x) { x.classList.toggle('on', x === b); }); renderAll(); });
    ['sample', 'real'].forEach(function (m) { $('d-' + m).onclick = function () { state.data = m; $('d-sample').classList.toggle('on', m === 'sample'); $('d-real').classList.toggle('on', m === 'real'); $('d-sample').setAttribute('aria-pressed', m === 'sample'); $('d-real').setAttribute('aria-pressed', m === 'real'); document.querySelector('h1 .sample').textContent = m === 'sample' ? 'SAMPLE DATA' : 'YOUR CURRENT DATA + SAMPLE JOB MARKET'; renderAll(); }; });
    function rz() { setTimeout(function () { Object.keys(CH).forEach(function (k) { CH[k].resize(); }); }, 40); }
    window.addEventListener('hashchange', rz);
    document.querySelectorAll('.tabs button').forEach(function (b) { b.addEventListener('click', rz); });
  }

  if (window.innerWidth < 760) $('slicers').removeAttribute('open');
  build(); bind(); renderAll();
  window.addEventListener('tiq-theme', function () {
    readTheme();
    Object.keys(CH).forEach(function (k) { CH[k].destroy(); delete CH[k]; });
    build(); renderAll();
  });
})();
