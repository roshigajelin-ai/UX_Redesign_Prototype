/* Tiny dependency-free SVG chart library for the TIQ World design mock.
   Every chart: TIQCharts.xxx(container, data, opts). Click handlers: opts.onClick(datum). */
(function () {
  /* Colours are CSS variables (defined in style.css for both themes) so charts re-colour instantly on theme change. */
  var COL = { teal: 'var(--c-teal)', violet: 'var(--c-violet)', blue: 'var(--c-blue)', green: 'var(--c-green)', amber: 'var(--c-amber)', red: 'var(--c-red)', pink: 'var(--c-pink)', grey: 'var(--c-grey)', grid: 'var(--line)', text: 'var(--sub)', track: 'var(--track)' };
  var PAL = [COL.violet, COL.teal, COL.blue, COL.amber, COL.green, COL.pink, COL.grey];
  function E(s) { return String(s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }
  function node(c) { return typeof c === 'string' ? document.querySelector(c) : c; }
  function dim(active, d) { return active && active.length && active.indexOf(d.key != null ? d.key : d.label) < 0 ? ' style="opacity:.3"' : ''; }
  function wire(c, data, onClick) {
    if (!onClick) return;
    c.querySelectorAll('[data-i]').forEach(function (n) {
      n.style.cursor = 'pointer'; n.setAttribute('tabindex', '0'); n.setAttribute('role', 'button');
      var go = function () { onClick(data[Number(n.getAttribute('data-i'))]); };
      n.addEventListener('click', go);
      n.addEventListener('keydown', function (e) { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); go(); } });
    });
  }
  function empty(c, msg) { c.innerHTML = '<div class="chart-empty">' + E(msg || 'No data for this selection') + '</div>'; }

  /* horizontal bars */
  function bar(c, data, o) {
    c = node(c); o = o || {};
    if (!data.length || data.every(function (d) { return !d.value; })) return empty(c, o.empty);
    var W = 560, rh = o.rowH || 30, lw = o.labelW || 118, H = data.length * rh + 6, max = o.max || Math.max.apply(null, data.map(function (d) { return d.value; })) || 1, bw = W - lw - 52, s = '';
    data.forEach(function (d, i) {
      var y = i * rh + 4, w = Math.max(2, d.value / max * bw), col = d.color || o.color || COL.violet;
      s += '<g' + dim(o.active, d) + ' data-i="' + i + '" data-tip="' + E(d.label + ': ' + d.value + (o.unit || '')) + '">' +
        '<text x="' + (lw - 8) + '" y="' + (y + 15) + '" text-anchor="end" font-size="12" fill="var(--body)">' + E(d.label) + '</text>' +
        '<rect x="' + lw + '" y="' + (y + 3) + '" width="' + bw + '" height="14" rx="4" fill="' + COL.track + '"/>' +
        '<rect x="' + lw + '" y="' + (y + 3) + '" width="' + w + '" height="14" rx="4" fill="' + col + '"/>' +
        '<text x="' + (lw + bw + 8) + '" y="' + (y + 15) + '" font-size="12" fill="' + COL.text + '">' + d.value + (o.unit || '') + '</text></g>';
    });
    c.innerHTML = '<svg viewBox="0 0 ' + W + ' ' + H + '" width="100%" role="img" aria-label="' + E(o.label || 'Bar chart') + '">' + s + '</svg>';
    wire(c, data, o.onClick);
  }

  /* vertical columns */
  function col(c, data, o) {
    c = node(c); o = o || {};
    if (!data.length || data.every(function (d) { return !d.value; })) return empty(c, o.empty);
    var W = 560, H = 210, pl = 30, pb = 40, pt = 14, max = Math.max.apply(null, data.map(function (d) { return d.value; })) || 1, n = data.length, bw = (W - pl) / n, s = '';
    for (var g = 0; g <= 3; g++) { var gy = pt + (H - pt - pb) * g / 3; s += '<line x1="' + pl + '" x2="' + W + '" y1="' + gy + '" y2="' + gy + '" stroke="' + COL.grid + '"/><text x="' + (pl - 6) + '" y="' + (gy + 4) + '" text-anchor="end" font-size="10" fill="' + COL.text + '">' + Math.round(max * (1 - g / 3)) + '</text>'; }
    data.forEach(function (d, i) {
      var h = d.value / max * (H - pt - pb), x = pl + i * bw + bw * .18, w = bw * .64;
      s += '<g' + dim(o.active, d) + ' data-i="' + i + '" data-tip="' + E(d.label + ': ' + d.value) + '"><rect x="' + x + '" y="' + (H - pb - h) + '" width="' + w + '" height="' + h + '" rx="4" fill="' + (d.color || o.color || COL.blue) + '"/>' +
        '<text x="' + (x + w / 2) + '" y="' + (H - pb - h - 5) + '" text-anchor="middle" font-size="11" fill="var(--body)">' + d.value + '</text>' +
        '<text x="' + (x + w / 2) + '" y="' + (H - pb + 16) + '" text-anchor="middle" font-size="10.5" fill="' + COL.text + '">' + E(d.label.length > 11 ? d.label.slice(0, 10) + '…' : d.label) + '</text></g>';
    });
    c.innerHTML = '<svg viewBox="0 0 ' + W + ' ' + H + '" width="100%" role="img" aria-label="' + E(o.label || 'Column chart') + '">' + s + '</svg>';
    wire(c, data, o.onClick);
  }

  /* donut with legend */
  function donut(c, data, o) {
    c = node(c); o = o || {};
    var tot = data.reduce(function (a, d) { return a + d.value; }, 0);
    if (!tot) return empty(c, o.empty);
    var R = 56, CIRC = 2 * Math.PI * R, off = 0, s = '', leg = '';
    data.forEach(function (d, i) {
      d.color = d.color || PAL[i % PAL.length];
      var len = d.value / tot * CIRC;
      s += '<circle data-i="' + i + '" cx="80" cy="80" r="' + R + '" fill="none" stroke="' + d.color + '" stroke-width="22" stroke-dasharray="' + len + ' ' + (CIRC - len) + '" stroke-dashoffset="' + (-off) + '" transform="rotate(-90 80 80)"' + dim(o.active, d) + ' data-tip="' + E(d.label + ': ' + d.value + ' (' + Math.round(d.value / tot * 100) + '%)') + '"/>';
      off += len;
      leg += '<li data-i="' + i + '"' + dim(o.active, d) + '><i style="background:' + d.color + '"></i>' + E(d.label) + ' <b>' + Math.round(d.value / tot * 100) + '%</b></li>';
    });
    var cen = o.center || { big: tot, small: o.centerLabel || 'total' };
    c.innerHTML = '<div class="donut"><svg viewBox="0 0 160 160" width="150" height="150" role="img" aria-label="' + E(o.label || 'Donut chart') + '">' + s +
      '<g pointer-events="none"><text x="80" y="82" text-anchor="middle" font-size="22" font-weight="700" fill="var(--strong)">' + E(cen.big) + '</text><text x="80" y="98" text-anchor="middle" font-size="10" fill="' + COL.text + '">' + E(cen.small) + '</text></g></svg><ul class="legend">' + leg + '</ul></div>';
    wire(c, data, o.onClick);
  }

  /* line / area, one or more series */
  function line(c, labels, series, o) {
    c = node(c); o = o || {};
    if (!Array.isArray(series[0].values)) series = [{ name: 'Value', values: series, color: COL.teal }];
    var W = o.W || 560, H = o.H || 200, pl = 30, pb = 28, pt = 14, pr = 12, max = o.max || Math.max.apply(null, [].concat.apply([], series.map(function (x) { return x.values; }))) || 1, n = labels.length, s = '';
    max = o.max || Math.ceil(max * 1.15);
    function X(i) { return pl + (n === 1 ? 0 : i * (W - pl - pr) / (n - 1)); }
    function Y(v) { return pt + (H - pt - pb) * (1 - v / max); }
    for (var g = 0; g <= 3; g++) { var gy = pt + (H - pt - pb) * g / 3; s += '<line x1="' + pl + '" x2="' + (W - pr) + '" y1="' + gy + '" y2="' + gy + '" stroke="' + COL.grid + '"/><text x="' + (pl - 6) + '" y="' + (gy + 4) + '" text-anchor="end" font-size="10" fill="' + COL.text + '">' + Math.round(max * (1 - g / 3)) + '</text>'; }
    labels.forEach(function (l, i) { s += '<text x="' + X(i) + '" y="' + (H - 8) + '" text-anchor="middle" font-size="10.5" fill="' + COL.text + '">' + E(l) + '</text>'; });
    series.forEach(function (se, k) {
      var cl = se.color || PAL[k], pts = se.values.map(function (v, i) { return X(i) + ',' + Y(v); }).join(' ');
      if (o.area !== false && k === 0) s += '<polygon points="' + X(0) + ',' + Y(0) + ' ' + pts + ' ' + X(n - 1) + ',' + Y(0) + '" fill="' + cl + '" opacity=".13"/>';
      s += '<polyline points="' + pts + '" fill="none" stroke="' + cl + '" stroke-width="2.5" stroke-linejoin="round"/>';
      se.values.forEach(function (v, i) { s += '<circle cx="' + X(i) + '" cy="' + Y(v) + '" r="4" fill="' + cl + '" data-tip="' + E((series.length > 1 ? se.name + ' · ' : '') + labels[i] + ': ' + v + (o.unit || '')) + '"/>'; });
    });
    var leg = series.length > 1 ? '<ul class="legend row-leg">' + series.map(function (x, k) { return '<li><i style="background:' + (x.color || PAL[k]) + '"></i>' + E(x.name) + '</li>'; }).join('') + '</ul>' : '';
    c.innerHTML = '<svg viewBox="0 0 ' + W + ' ' + H + '" width="100%" role="img" aria-label="' + E(o.label || 'Line chart') + '">' + s + '</svg>' + leg;
  }

  /* sparkline */
  function spark(c, values, color) {
    c = node(c); color = color || COL.teal;
    var W = 100, H = 28, max = Math.max.apply(null, values) || 1, min = Math.min.apply(null, values), rg = (max - min) || 1;
    var pts = values.map(function (v, i) { return (i * W / (values.length - 1)) + ',' + (H - 3 - (v - min) / rg * (H - 6)); }).join(' ');
    c.innerHTML = '<svg viewBox="0 0 ' + W + ' ' + H + '" width="100%" height="28" preserveAspectRatio="none" aria-hidden="true"><polygon points="0,' + H + ' ' + pts + ' ' + W + ',' + H + '" fill="' + color + '" opacity=".15"/><polyline points="' + pts + '" fill="none" stroke="' + color + '" stroke-width="2" vector-effect="non-scaling-stroke"/></svg>';
  }

  /* funnel */
  function funnel(c, data, o) {
    c = node(c); o = o || {};
    if (!data.length || !data[0].value) return empty(c, o.empty);
    var cols = [COL.violet, 'var(--c-violet2)', COL.blue, COL.teal, COL.green], s = '';
    data.forEach(function (d, i) {
      var w = Math.max(24, d.value / data[0].value * 100), pct = i ? Math.round(d.value / data[i - 1].value * 100) : 100;
      s += '<div class="fn-row" data-i="' + i + '" data-tip="' + E(d.label + ': ' + d.value + (i ? ' (' + pct + '% of previous)' : '')) + '"><span class="fn-l">' + E(d.label) + '</span><div class="fn-t"><div class="fn-b" style="width:' + w + '%;background:' + cols[i % 5] + '">' + d.value + '</div></div><span class="fn-p">' + (i ? pct + '%' : '') + '</span></div>';
    });
    c.innerHTML = '<div role="img" aria-label="' + E(o.label || 'Funnel chart') + '">' + s + '</div>';
    wire(c, data, o.onClick);
  }

  /* gauge (0-100) */
  function gauge(c, value, o) {
    c = node(c); o = o || {};
    var R = 70, cx = 90, cy = 90, a = Math.PI * (1 - value / 100), x = cx + R * Math.cos(a), y = cy - R * Math.sin(a), col = value >= 75 ? COL.green : value >= 50 ? COL.teal : COL.amber;
    c.innerHTML = '<svg viewBox="0 0 180 112" width="100%" style="max-width:240px" role="img" aria-label="' + E(o.label || 'Gauge') + ' ' + value + ' percent">' +
      '<path d="M' + (cx - R) + ',' + cy + ' A' + R + ',' + R + ' 0 0 1 ' + (cx + R) + ',' + cy + '" fill="none" stroke="' + COL.track + '" stroke-width="16" stroke-linecap="round"/>' +
      '<path d="M' + (cx - R) + ',' + cy + ' A' + R + ',' + R + ' 0 0 1 ' + x + ',' + y + '" fill="none" stroke="' + col + '" stroke-width="16" stroke-linecap="round" data-tip="' + E((o.label || 'Score') + ': ' + value + '%') + '"/>' +
      '<text x="90" y="86" text-anchor="middle" font-size="28" font-weight="700" fill="var(--strong)">' + value + '%</text><text x="90" y="104" text-anchor="middle" font-size="10" fill="' + COL.text + '">' + E(o.sub || '') + '</text></svg>';
  }

  /* radar / spider */
  function radar(c, labels, series, o) {
    c = node(c); o = o || {};
    var cx = 150, cy = 120, R = 82, n = labels.length, s = '';
    function P(i, v) { var a = -Math.PI / 2 + i * 2 * Math.PI / n; return [cx + R * v / 100 * Math.cos(a), cy + R * v / 100 * Math.sin(a)]; }
    [25, 50, 75, 100].forEach(function (g) { s += '<polygon points="' + labels.map(function (_, i) { return P(i, g).join(','); }).join(' ') + '" fill="none" stroke="' + COL.grid + '"/>'; });
    labels.forEach(function (l, i) { var p = P(i, 100), q = P(i, 118); s += '<line x1="' + cx + '" y1="' + cy + '" x2="' + p[0] + '" y2="' + p[1] + '" stroke="' + COL.grid + '"/><text x="' + q[0] + '" y="' + (q[1] + 4) + '" text-anchor="middle" font-size="11" fill="var(--body)">' + E(l) + '</text>'; });
    series.forEach(function (se, k) {
      var cl = se.color || PAL[k + 1];
      s += '<polygon points="' + se.values.map(function (v, i) { return P(i, v).join(','); }).join(' ') + '" fill="' + cl + '" fill-opacity=".22" stroke="' + cl + '" stroke-width="2"/>';
      se.values.forEach(function (v, i) { var p = P(i, v); s += '<circle cx="' + p[0] + '" cy="' + p[1] + '" r="3.5" fill="' + cl + '" data-tip="' + E(se.name + ' · ' + labels[i] + ': ' + v + '%') + '"/>'; });
    });
    c.innerHTML = '<svg viewBox="0 0 300 245" width="100%" style="max-width:380px" role="img" aria-label="' + E(o.label || 'Radar chart') + '">' + s + '</svg><ul class="legend row-leg">' + series.map(function (x, k) { return '<li><i style="background:' + (x.color || PAL[k + 1]) + '"></i>' + E(x.name) + '</li>'; }).join('') + '</ul>';
  }

  /* activity heatmap: rows = days, cols = weeks, values 0-4 */
  function heat(c, m, o) {
    c = node(c); o = o || {};
    var days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'], cs = 17, s = '';
    m.forEach(function (row, d) {
      s += '<text x="0" y="' + (d * cs + 13) + '" font-size="10" fill="' + COL.text + '">' + days[d] + '</text>';
      row.forEach(function (v, w) { s += '<rect x="' + (34 + w * cs) + '" y="' + (d * cs) + '" width="14" height="14" rx="3" fill="' + COL.teal + '" fill-opacity="' + (v ? 0.14 + v * 0.21 : 0.05) + '" data-tip="' + days[d] + ', week ' + (w + 1) + ': ' + (v * 30) + ' min"/>'; });
    });
    c.innerHTML = '<svg viewBox="0 0 ' + (34 + m[0].length * cs) + ' ' + (7 * cs) + '" width="100%" role="img" aria-label="' + E(o.label || 'Activity heatmap') + '">' + s + '</svg><div class="note" style="margin-top:6px">Less <span class="hm-scale"><i></i><i></i><i></i><i></i></span> More</div>';
  }

  window.TIQCharts = { bar: bar, col: col, donut: donut, line: line, spark: spark, funnel: funnel, gauge: gauge, radar: radar, heat: heat, COL: COL, PAL: PAL };
})();
