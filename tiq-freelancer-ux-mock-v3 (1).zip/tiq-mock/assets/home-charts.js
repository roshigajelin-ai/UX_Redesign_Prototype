/* Home "Work analytics" band: KPI tiles + 4 linked charts with a date range and click-to-filter.
   Sample data only (INSDATA, seeded). Theme colours come from CSS variables, so charts follow light/dark instantly. */
(function () {
  var T = window.INSDATA, D = window.TIQDATA, root = document.getElementById('wa');
  if (!T || !root) return;
  var TODAY = new Date(2026, 9, 12);
  var RANGES = { '7D': 7, '30D': 30, '6M': 180, '1Y': 365 }, RLABEL = { '7D': 'last 7 days', '30D': 'last 30 days', '6M': 'last 6 months', '1Y': 'last 12 months' };
  var NB = { '7D': 7, '30D': 6, '6M': 6, '1Y': 12 };
  var COLS = ['var(--c-blue)', 'var(--c-orange)', 'var(--c-green2)', 'var(--c-amber)', 'var(--c-pink)', 'var(--c-violet)'];
  var DIMS = { skill: { vals: T.SKILLS.map(function (s) { return s.k; }), label: 'Skill' }, mode: { vals: ['Onsite', 'Hybrid', 'Remote'], label: 'Work mode' }, type: { vals: T.TYPES, label: 'Type' } };
  var state = { range: '6M', sel: { skill: new Set(), mode: new Set(), type: new Set() } };
  var byId = {}; T.jobs.forEach(function (j) { byId[j.id] = j; });
  var E = function (s) { return String(s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); };
  function dt(daysAgo) { var d = new Date(TODAY); d.setDate(d.getDate() - daysAgo); return d; }
  function f(d, y) { return d.toLocaleDateString('en-GB', y ? { day: '2-digit', month: 'short', year: 'numeric' } : { day: 'numeric', month: 'short' }); }
  function ok(j, skip) { return Object.keys(state.sel).every(function (k) { return k === skip || !state.sel[k].size || state.sel[k].has(j[k]); }); }
  function jobsIn(a, b, skip) { return T.jobs.filter(function (j) { return j.daysAgo >= a && j.daysAgo < b && ok(j, skip); }); }
  function appsIn(a, b) { return T.apps.filter(function (x) { return x.daysAgo >= a && x.daysAgo < b && ok(byId[x.job]); }); }
  function delta(cur, prev, days) {
    if (!prev) return { t: 'no earlier data', c: 'flat' };
    var p = Math.round((cur - prev) / prev * 100);
    return { t: (p >= 0 ? '↑ ' : '↓ ') + Math.abs(p) + '% vs previous ' + (days <= 30 ? days + ' days' : days === 180 ? '6 months' : '12 months'), c: p >= 0 ? 'up' : 'dn' };
  }
  function series(fn, days, n) { var size = days / n, out = []; for (var i = 0; i < n; i++) { var a = Math.round((n - 1 - i) * size), b = Math.round((n - i) * size); out.push({ a: a, b: b, v: fn(a, b) }); } return out; }
  function spark(vals, col) {
    var W = 120, H = 30, mx = Math.max.apply(null, vals.concat([1])), pts = vals.map(function (v, i) { return [i / (vals.length - 1) * W, H - 3 - v / mx * (H - 8)]; });
    return '<svg viewBox="0 0 ' + W + ' ' + H + '" preserveAspectRatio="none" aria-hidden="true"><polyline fill="none" stroke="' + col + '" stroke-width="2" stroke-linejoin="round" stroke-linecap="round" points="' + pts.map(function (p) { return p.join(','); }).join(' ') + '"/></svg>';
  }

  function kpis(days) {
    var n = NB[state.range], cJ = jobsIn(0, days).length, pJ = days <= 30 ? jobsIn(days, days * 2).length : 0;
    var cA = appsIn(0, days), pA = days <= 365 && days < 365 ? appsIn(days, days * 2).length : 0, sel = cA.filter(function (a) { return a.reached === 4; }).length;
    var jS = series(function (a, b) { return jobsIn(a, b).length; }, days, n).map(function (x) { return x.v; });
    var aS = series(function (a, b) { return appsIn(a, b).length; }, days, n).map(function (x) { return x.v; });
    var sS = series(function (a, b) { return appsIn(a, b).filter(function (x) { return x.reached === 4; }).length; }, days, n).map(function (x) { return x.v; });
    var nxt = D.contracts.slice().sort(function (a, b) { return a.deadline < b.deadline ? -1 : 1; })[0];
    var dj = delta(cJ, pJ, days), da = delta(cA.length, pA, days);
    return [
      { t: 'Opportunities', v: cJ, d: dj, s: jS, c: 'var(--c-violet)', h: 'jobs.html' },
      { t: 'Applications', v: cA.length, d: da, s: aS, c: 'var(--c-teal)', h: 'work.html#applications' },
      { t: 'Active work', v: D.contracts.length, d: { t: 'next deadline ' + f(new Date(nxt.deadline + 'T00:00:00')), c: 'flat' }, s: D.contracts.map(function (c) { return c.progress; }).concat([0]).slice(0, 2).concat([D.contracts[0].progress]), c: 'var(--c-green)', h: 'work.html#contracts' },
      { t: 'Selected', v: sel, d: { t: cA.length ? Math.round(sel / cA.length * 100) + '% success rate' : 'no applications in range', c: 'flat' }, s: sS, c: 'var(--c-amber)', h: 'work.html#applications' }
    ];
  }

  function lineChart(days) {
    var n = NB[state.range], pts = series(function (a, b) { return appsIn(a, b).length; }, days, n), W = 480, H = 240, pl = 34, pr = 14, pt = 16, pb = 30;
    var mx = Math.max.apply(null, pts.map(function (p) { return p.v; }).concat([3])); mx = Math.ceil(mx / 3) * 3;
    var X = function (i) { return pl + i * (W - pl - pr) / (n - 1); }, Y = function (v) { return pt + (H - pt - pb) * (1 - v / mx); };
    var s = '<svg viewBox="0 0 ' + W + ' ' + H + '" role="img" aria-label="Applications over time, ' + RLABEL[state.range] + '"><defs><linearGradient id="lg" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="var(--c-teal)" stop-opacity=".35"/><stop offset="1" stop-color="var(--c-teal)" stop-opacity="0"/></linearGradient></defs>';
    for (var g = 0; g <= 3; g++) { var gy = pt + (H - pt - pb) * g / 3; s += '<line x1="' + pl + '" x2="' + (W - pr) + '" y1="' + gy + '" y2="' + gy + '" stroke="var(--line)"/><text x="' + (pl - 8) + '" y="' + (gy + 4) + '" text-anchor="end" font-size="11" fill="var(--sub)">' + Math.round(mx * (1 - g / 3)) + '</text>'; }
    var d = '';
    pts.forEach(function (p, i) { var x = X(i), y = Y(p.v); if (!i) d = 'M' + x + ',' + y; else { var px = X(i - 1), py = Y(pts[i - 1].v), cx = (px + x) / 2; d += ' C' + cx + ',' + py + ' ' + cx + ',' + y + ' ' + x + ',' + y; } });
    s += '<path d="' + d + ' L' + X(n - 1) + ',' + (H - pb) + ' L' + X(0) + ',' + (H - pb) + 'Z" fill="url(#lg)"/><path d="' + d + '" fill="none" stroke="var(--c-teal)" stroke-width="3" stroke-linecap="round"/>';
    pts.forEach(function (p, i) {
      var end = dt(p.a), st = dt(p.b - 1), lab = state.range === '1Y' ? end.toLocaleDateString('en-GB', { month: 'short' }) : f(end);
      s += '<text x="' + X(i) + '" y="' + (H - 8) + '" text-anchor="middle" font-size="11" fill="var(--sub)">' + lab + '</text>' +
        '<circle cx="' + X(i) + '" cy="' + Y(p.v) + '" r="' + (i === n - 1 ? 6 : 4.5) + '" fill="var(--c-teal)" stroke="var(--panel)" stroke-width="2" data-tip="' + E((p.b - p.a > 1 ? f(st) + ' – ' + f(end) : f(end)) + ': ' + p.v + ' application' + (p.v === 1 ? '' : 's')) + '"/>';
    });
    return s + '</svg>';
  }

  function counts(dim, days) { return DIMS[dim].vals.map(function (v) { return { v: v, n: T.jobs.filter(function (j) { return j[dim] === v && ok(j, dim); }).length }; }); }
  function act(dim, v) { var on = state.sel[dim].has(v), any = state.sel[dim].size; return { on: on, dim: any && !on }; }
  function btn(dim, v, tip, inner) { var a = act(dim, v); return '<g class="wa-b" tabindex="0" role="button" aria-pressed="' + a.on + '" data-dim="' + dim + '" data-val="' + E(v) + '" data-tip="' + E(tip) + '" opacity="' + (a.dim ? .35 : 1) + '">' + inner + '</g>'; }

  function donut(days) {
    var c = counts('mode', days), tot = c.reduce(function (s, x) { return s + x.n; }, 0), R = 62, C = 2 * Math.PI * R, off = 0, s = '';
    s = '<svg viewBox="0 0 170 170" role="img" aria-label="Work mode distribution"><circle cx="85" cy="85" r="' + R + '" fill="none" stroke="var(--track)" stroke-width="24"/>';
    c.forEach(function (x, i) { var len = tot ? x.n / tot * C : 0, gap = len > 4 ? 2 : 0;
      if (len) s += btn('mode', x.v, x.v + ': ' + x.n + ' (' + Math.round(x.n / tot * 100) + '%)', '<circle cx="85" cy="85" r="' + R + '" fill="none" stroke="' + COLS[i] + '" stroke-width="24" stroke-dasharray="' + (len - gap) + ' ' + (C - len + gap) + '" stroke-dashoffset="' + (-off) + '" transform="rotate(-90 85 85)"/>');
      off += len; });
    s += '<text pointer-events="none" x="85" y="84" text-anchor="middle" font-size="26" font-weight="700" fill="var(--strong)">' + tot + '</text><text pointer-events="none" x="85" y="102" text-anchor="middle" font-size="11" fill="var(--sub)">open roles</text></svg>';
    var leg = c.map(function (x, i) { var a = act('mode', x.v); return '<li><button class="wa-leg" data-dim="mode" data-val="' + x.v + '" aria-pressed="' + a.on + '"' + (a.dim ? ' style="opacity:.5"' : '') + '><i style="background:' + COLS[i] + '"></i>' + x.v + '<b>' + x.n + (tot ? ' · ' + Math.round(x.n / tot * 100) + '%' : '') + '</b></button></li>'; }).join('');
    return '<div class="wa-donut">' + s + '<ul class="wa-legend">' + leg + '</ul></div>';
  }

  function hbars(days) {
    var c = counts('skill', days).sort(function (a, b) { return b.n - a.n; }), mx = Math.max.apply(null, c.map(function (x) { return x.n; }).concat([1])), W = 440, rh = 36, lw = 140, s = '<svg viewBox="0 0 ' + W + ' ' + (c.length * rh + 4) + '" role="img" aria-label="Top skills in demand">';
    c.forEach(function (x, i) { var y = i * rh + 2, w = Math.max(3, x.n / mx * (W - lw - 50)), idx = DIMS.skill.vals.indexOf(x.v), nm = T.SKILLS[idx].name;
      s += btn('skill', x.v, nm + ': ' + x.n + ' open roles', '<rect x="0" y="' + y + '" width="' + W + '" height="' + (rh - 4) + '" fill="transparent"/><text x="' + (lw - 10) + '" y="' + (y + 19) + '" text-anchor="end" font-size="12.5" fill="var(--body)">' + E(nm) + '</text><rect x="' + lw + '" y="' + (y + 5) + '" width="' + (W - lw - 40) + '" height="16" rx="8" fill="var(--track)"/><rect x="' + lw + '" y="' + (y + 5) + '" width="' + w + '" height="16" rx="8" fill="' + COLS[idx] + '"/><text x="' + (W - 6) + '" y="' + (y + 19) + '" text-anchor="end" font-size="12.5" font-weight="600" fill="var(--text)">' + x.n + '</text>'); });
    return s + '</svg>';
  }

  function columns(days) {
    var c = counts('type', days), mx = Math.max.apply(null, c.map(function (x) { return x.n; }).concat([4])), W = 440, H = 230, pl = 30, pb = 30, pt = 18, bw = (W - pl) / c.length, s = '<svg viewBox="0 0 ' + W + ' ' + H + '" role="img" aria-label="Opportunities by employment type">';
    mx = Math.ceil(mx / 4) * 4;
    for (var g = 0; g <= 4; g++) { var gy = pt + (H - pt - pb) * g / 4; s += '<line x1="' + pl + '" x2="' + W + '" y1="' + gy + '" y2="' + gy + '" stroke="var(--line)"/><text x="' + (pl - 6) + '" y="' + (gy + 4) + '" text-anchor="end" font-size="11" fill="var(--sub)">' + Math.round(mx * (1 - g / 4)) + '</text>'; }
    c.forEach(function (x, i) { var h = (H - pt - pb) * x.n / mx, bx = pl + i * bw + bw * .2, w = bw * .6;
      s += btn('type', x.v, x.v + ': ' + x.n + ' open roles', '<rect x="' + (pl + i * bw) + '" y="' + pt + '" width="' + bw + '" height="' + (H - pt - pb + 24) + '" fill="transparent"/><rect x="' + bx + '" y="' + (H - pb - h) + '" width="' + w + '" height="' + Math.max(h, 2) + '" rx="5" fill="var(--c-blue)"/><text x="' + (bx + w / 2) + '" y="' + (H - pb - h - 6) + '" text-anchor="middle" font-size="11.5" font-weight="600" fill="var(--text)">' + x.n + '</text><text x="' + (bx + w / 2) + '" y="' + (H - 9) + '" text-anchor="middle" font-size="11" fill="var(--sub)">' + E(x.v) + '</text>'); });
    return s + '</svg>';
  }

  function render() {
    var days = RANGES[state.range], k = kpis(days), from = dt(days - 1), n = 0;
    Object.keys(state.sel).forEach(function (d) { n += state.sel[d].size; });
    document.getElementById('wa-range').textContent = f(from, 1) + ' – ' + f(TODAY, 1);
    document.querySelectorAll('#wa-seg button').forEach(function (b) { b.setAttribute('aria-pressed', b.dataset.r === state.range); b.classList.toggle('on', b.dataset.r === state.range); });
    var chips = '';
    Object.keys(state.sel).forEach(function (d) { state.sel[d].forEach(function (v) { chips += '<button class="wa-chip" data-dim="' + d + '" data-val="' + E(v) + '" aria-label="Remove filter ' + E(v) + '">' + DIMS[d].label + ': ' + E(v) + ' ✕</button>'; }); });
    document.getElementById('wa-chips').innerHTML = chips + (n ? '<button class="wa-clear" id="wa-clear">Clear all</button>' : '<span class="xs faint">Click a slice, bar or column to filter every chart.</span>');
    document.getElementById('wa-kpis').innerHTML = k.map(function (x) {
      return '<a class="wa-kpi" href="' + x.h + '"><span class="l">' + x.t + '</span><span class="v">' + x.v + '</span><span class="d ' + x.d.c + '">' + x.d.t + '</span>' + spark(x.s, x.c) + '</a>';
    }).join('');
    document.getElementById('wa-line').innerHTML = lineChart(days);
    document.getElementById('wa-donut').innerHTML = donut(days);
    document.getElementById('wa-skills').innerHTML = hbars(days);
    document.getElementById('wa-types').innerHTML = columns(days);
    document.getElementById('wa-sub1').textContent = f(from) + ' – ' + f(TODAY) + ' · ' + RLABEL[state.range];
  }
  function toggle(dim, v) { var s = state.sel[dim]; if (s.has(v)) s['delete'](v); else s.add(v); render(); }

  root.addEventListener('click', function (e) {
    var r = e.target.closest('#wa-seg button'); if (r) { state.range = r.dataset.r; render(); return; }
    if (e.target.closest('#wa-clear')) { Object.keys(state.sel).forEach(function (d) { state.sel[d].clear(); }); render(); return; }
    var t = e.target.closest('[data-dim]'); if (t) toggle(t.dataset.dim, t.dataset.val);
  });
  root.addEventListener('keydown', function (e) { if ((e.key === 'Enter' || e.key === ' ') && e.target.matches('.wa-b')) { e.preventDefault(); toggle(e.target.dataset.dim, e.target.dataset.val); } });
  render();
})();
