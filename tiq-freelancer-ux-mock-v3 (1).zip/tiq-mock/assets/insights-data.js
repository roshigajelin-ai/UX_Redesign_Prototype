/* Dummy dataset for the TIQ World insights mock. All values are invented. Seeded so every load is identical. */
window.INSDATA = (function () {
  function rng(a) {
    return function () {
      a |= 0; a = (a + 0x6D2B79F5) | 0;
      var t = Math.imul(a ^ (a >>> 15), 1 | a);
      t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  }
  var r = rng(20261012);
  function pick(list) { // weighted pick, list of [value, weight]
    var sum = list.reduce(function (s, x) { return s + x[1]; }, 0), n = r() * sum;
    for (var i = 0; i < list.length; i++) { n -= list[i][1]; if (n <= 0) return list[i][0]; }
    return list[list.length - 1][0];
  }

  // Colour follows the entity (validated categorical order, dark mode)
  var SKILLS = [
    { k: 'UT', name: 'Ultrasonic Testing', color: '#3987e5' },
    { k: 'MT', name: 'Magnetic Particle', color: '#d95926' },
    { k: 'PT', name: 'Liquid Penetrant', color: '#199e70' },
    { k: 'RT', name: 'Radiographic', color: '#c98500' },
    { k: 'AE', name: 'Acoustic Emission', color: '#d55181' },
    { k: 'AI', name: 'AI in Manufacturing', color: '#9085e9' }
  ];
  var INDUSTRIES = [
    { k: 'Oil & Gas', color: '#3987e5' }, { k: 'Manufacturing', color: '#d95926' },
    { k: 'Aerospace', color: '#199e70' }, { k: 'Power', color: '#c98500' },
    { k: 'Automotive', color: '#d55181' }, { k: 'Marine', color: '#9085e9' }
  ];
  var MODES = [{ k: 'Onsite', color: '#3987e5' }, { k: 'Hybrid', color: '#d95926' }, { k: 'Remote', color: '#199e70' }];
  var TYPES = ['Full Time', 'Contract', 'Man Day', 'Man Month', 'Part Time', 'Internship'];
  var LOCS = ['Chennai', 'Mumbai', 'Bengaluru', 'Hyderabad', 'Pune'];

  var titles = {
    UT: ['Ultrasonic Testing Specialist', 'UT Level II Inspector'],
    MT: ['MT Inspector (Level II)', 'Magnetic Particle Technician'],
    PT: ['Penetrant Testing Technician', 'PT Level II Inspector'],
    RT: ['Radiographic Interpreter', 'RT Level II Technician'],
    AE: ['Acoustic Emission Technician', 'AE Monitoring Engineer'],
    AI: ['AI Inspection Analyst', 'Smart Manufacturing Analyst']
  };
  var companies = ['Gulf Pipeline Services', 'Northline Aerospace', 'Petrochem Works', 'Fabrik Industrial', 'Meridian Power', 'Bluewave Marine', 'Autocraft Motors', 'Ironbridge Labs'];
  // Your self-declared proficiency (0-100) in each skill, used for match % and the skill-gap chart
  var level = { UT: 45, MT: 65, PT: 10, RT: 10, AE: 60, AI: 40 };
  var matchBase = { UT: 42, MT: 58, PT: 36, RT: 34, AE: 82, AI: 78 };

  var jobs = [];
  for (var i = 0; i < 120; i++) {
    var skill = pick([['UT', 24], ['MT', 18], ['PT', 13], ['RT', 11], ['AE', 8], ['AI', 7]]);
    var m = Math.round(matchBase[skill] + (r() * 18 - 8));
    jobs.push({
      id: i + 1,
      skill: skill,
      title: titles[skill][Math.floor(r() * 2)],
      company: companies[Math.floor(r() * companies.length)],
      industry: pick([['Oil & Gas', 30], ['Manufacturing', 24], ['Aerospace', 16], ['Power', 12], ['Automotive', 10], ['Marine', 8]]),
      mode: pick([['Onsite', 40], ['Hybrid', 35], ['Remote', 25]]),
      type: pick([['Full Time', 32], ['Contract', 22], ['Man Day', 16], ['Man Month', 12], ['Part Time', 9], ['Internship', 7]]),
      loc: pick([['Chennai', 35], ['Mumbai', 28], ['Bengaluru', 22], ['Hyderabad', 18], ['Pune', 15]]),
      daysAgo: Math.floor(r() * 84),
      match: Math.max(20, Math.min(98, m))
    });
  }

  // Sample applications: reached = furthest stage 0..4 (Applied, Under review, Shortlisted, Interview, Selected)
  var used = {}, apps = [];
  while (apps.length < 44) {
    var jid = 1 + Math.floor(r() * 120);
    if (used[jid]) continue; used[jid] = 1;
    var reached = pick([[0, 30], [1, 25], [2, 20], [3, 15], [4, 10]]);
    apps.push({
      job: jid, reached: reached,
      rejected: reached < 4 && r() < 0.35,
      daysAgo: Math.floor(Math.pow(r(), 2) * 365)
    });
  }

  var courses = {
    sample: [
      { id: 'mpt', name: 'Magnetic Particle Testing', skill: 'MT', hours: 10, done: 6.5 },
      { id: 'ut', name: 'Ultrasonic Testing Level II', skill: 'UT', hours: 12, done: 5.4 },
      { id: 'aim', name: 'AI in Manufacturing', skill: 'AI', hours: 8, done: 2 },
      { id: 'ae', name: 'Acoustic Emission Basics', skill: 'AE', hours: 6, done: 6 }
    ],
    real: [{ id: 'mpt', name: 'Magnetic Particle Testing', skill: 'MT', hours: 10, done: 0 }]
  };

  var heat = [];
  for (var w = 0; w < 12; w++) for (var d = 0; d < 7; d++) {
    var v = r(); heat.push(v < 0.35 ? 0 : v < 0.6 ? 1 : v < 0.8 ? 2 : v < 0.93 ? 3 : 4);
  }

  return {
    SKILLS: SKILLS, INDUSTRIES: INDUSTRIES, MODES: MODES, TYPES: TYPES, LOCS: LOCS,
    level: level, jobs: jobs, apps: apps, courses: courses, heat: heat,
    today: '12 Oct 2026'
  };
})();
