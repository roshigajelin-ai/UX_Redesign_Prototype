/* Shared job UI: job modal, apply (simulated), save toggle. Requires data.js + app.js */
(function () {
  var D = TIQDATA, E = TIQ.esc;
  function fit(j) {
    var has = D.USER_SKILLS.indexOf(j.skill) >= 0;
    return [
      [has, D.SKILLS[j.skill], has ? 'On your profile (unverified)' : 'Not on your profile'],
      [false, j.cert + ' certificate', 'Not yet earned'],
      [j.exp <= 1, j.exp + '+ years experience', '1 year on profile']
    ];
  }
  function pillFor(m) { return m >= 75 ? 'g' : m >= 60 ? 'y' : ''; }
  function ago(d) { return d === 0 ? 'today' : d === 1 ? '1d ago' : d + 'd ago'; }

  function jobModal(j, after) {
    var applied = TIQ.jobs.isApplied(j.id), saved = TIQ.jobs.isSaved(j.id);
    var rows = fit(j).map(function (f) { return '<div class="row between" style="padding:6px 0;border-bottom:1px solid var(--line)"><span>' + (f[0] ? '✓' : '✗') + ' ' + E(f[1]) + '</span><span class="pill ' + (f[0] ? 'y' : 'r') + '">' + E(f[2]) + '</span></div>'; }).join('');
    TIQ.modal({
      title: j.title,
      body: '<div class="sub sm" style="margin-bottom:10px">' + E(j.company) + ' · ' + E(j.location) + ' · ' + j.mode + ' · ' + j.type + '</div>' +
        '<div class="chips" style="margin-bottom:12px"><span class="pill ' + pillFor(j.match) + '">' + j.match + '% match</span><span class="pill">' + E(j.industry) + '</span><span class="pill">' + j.openings + ' opening' + (j.openings > 1 ? 's' : '') + '</span><span class="pill">Posted ' + ago(j.posted) + '</span></div>' +
        '<p class="sub" style="margin-bottom:12px">Perform ' + E(D.SKILLS[j.skill]) + ' on site assets, record findings and prepare inspection reports. Sample description for the design mock.</p>' +
        '<h3 style="margin-bottom:4px">Your fit</h3>' + rows +
        (applied ? '<div class="callout" style="margin-top:12px">You applied to this job (simulated). Track it in <a class="teal" href="work.html#applications">My Work → Applications</a>.</div>' : ''),
      note: 'Dummy data. Save and Apply are simulated and stored only in this browser.',
      actions: [
        { label: saved ? '★ Saved' : '☆ Save', kind: 'line', close: false, onClick: function (e) { var on = TIQ.jobs.toggleSave(j.id); e.target.textContent = on ? '★ Saved' : '☆ Save'; TIQ.toast(on ? 'Job saved' : 'Removed from saved'); if (after) after(); } },
        { label: 'Full page', kind: 'line', href: 'job-detail.html?id=' + j.id },
        applied ? { label: 'Applied ✓', kind: 'line', close: false, onClick: function () { } } : { label: 'Apply', onClick: function () { applyModal(j, after); }, close: false }
      ]
    });
  }
  function applyModal(j, after) {
    TIQ.modal({
      title: 'Apply to ' + j.title,
      body: '<p class="sub" style="margin-bottom:10px">Your TIQ profile will be shared with ' + E(j.company) + '.</p>' +
        '<div class="card" style="background:var(--panel2)"><b>Priya Sample</b><div class="sm sub">NDT Technician · Chennai · Skills: Acoustic Emission, AI in Manufacturing</div></div>' +
        '<label class="sm sub" style="display:block;margin:12px 0 4px" for="cov">Note to employer (optional)</label><textarea id="cov" class="field" rows="3" placeholder="Short message"></textarea>' +
        '<div class="callout" style="margin-top:12px"><b>Simulated.</b> Nothing is sent to a real backend.</div>',
      actions: [{ label: 'Submit application', onClick: function () { TIQ.jobs.apply(j.id); TIQ.toast('Application submitted'); if (after) after(); } }]
    });
  }
  function card(j) {
    return '<div class="job item" data-job="' + j.id + '" tabindex="0" role="button" aria-label="' + E(j.title) + ' at ' + E(j.company) + '"><div class="logo-sq">' + j.skill + '</div><div class="grow"><b>' + E(j.title) + '</b>' +
      '<div class="sub sm">' + E(j.company) + '</div><div class="sub sm">' + j.location + ' · ' + j.mode + ' · ' + j.type + '</div>' +
      '<div class="row" style="margin-top:6px;flex-wrap:wrap"><span class="pill ' + pillFor(j.match) + '">' + j.match + '% match</span>' + (TIQ.jobs.isApplied(j.id) ? '<span class="pill t">Applied</span>' : '') + '<span class="xs faint">' + ago(j.posted) + '</span></div></div>' +
      '<button class="save ' + (TIQ.jobs.isSaved(j.id) ? 'on' : '') + '" data-save="' + j.id + '" aria-label="Save job" aria-pressed="' + TIQ.jobs.isSaved(j.id) + '">' + (TIQ.jobs.isSaved(j.id) ? '★' : '☆') + '</button></div>';
  }
  /* delegate clicks inside a container: card -> modal, star -> toggle */
  function bind(container, rerender) {
    container.addEventListener('click', function (e) {
      var sv = e.target.closest('[data-save]');
      if (sv) { e.stopPropagation(); var on = TIQ.jobs.toggleSave(Number(sv.getAttribute('data-save'))); TIQ.toast(on ? 'Job saved' : 'Removed from saved'); rerender(); return; }
      var c = e.target.closest('[data-job]'); if (c) jobModal(TIQ.jobs.get(c.getAttribute('data-job')), rerender);
    });
    container.addEventListener('keydown', function (e) { if ((e.key === 'Enter' || e.key === ' ') && e.target.matches('[data-job]')) { e.preventDefault(); e.target.click(); } });
  }
  function listModal(title, jobs, after) {
    var body = jobs.length ? '<div class="list" id="lm">' + jobs.slice(0, 10).map(card).join('') + '</div>' : '<div class="chart-empty">No jobs for this selection</div>';
    var m = TIQ.modal({ title: title, body: body + (jobs.length > 10 ? '<p class="note" style="margin-top:8px">Showing 10 of ' + jobs.length + '.</p>' : ''), actions: [{ label: 'Open Jobs page', href: 'jobs.html' }] });
    var lm = m.querySelector('#lm'); if (lm) bind(lm, function () { TIQ.closeModal(); if (after) after(); listModal(title, jobs, after); });
  }
  TIQ.jobModal = jobModal; TIQ.applyModal = applyModal; TIQ.jobCard = card; TIQ.bindJobs = bind; TIQ.jobList = listModal; TIQ.pillFor = pillFor;
})();
